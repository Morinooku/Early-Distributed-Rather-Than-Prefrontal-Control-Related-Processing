clear;close all
config = struct();
config.dataDir = '';
config.numSubjects = [];
config.outputDir = '';
config.useLSSM = false;
config.predictor = 'LDA';%'logistic', 'SVM', 'LDA'
config.numFolds = 10;                   % Empty = LOOCV
config.numPermutations = 1000;
config.trainMinDistFromTest = 4;
config.lssmHorizon = 10;
config.lssmMaxNx = 10;
config.ldaGamma = 0.2;                  
config.fastPermLDA = true;             
config.numWorkers = [];                 % Max workers for subject parfor ([] = use all cores; set e.g. 20-40 if memory-limited)
config.verbose = false;
config.progressEvery = 100;             
config.useParallel = true;
config.randomSeed = 1;                  
config.nFeatSub = 12;                   
config.timeDraw = 1;                 
config.groupNumPermutations = 10000;
config.featurePermutations = 10000;
config.alphaLevel = 0.05;
config.runBothMethods = false;
config.applyFDR = true;
config.plotROC = true;                 
config.rocInterpolationPoints = 101;    
if ~isscalar(config.nFeatSub) || config.nFeatSub < 1 || config.nFeatSub ~= round(config.nFeatSub)
    error('config.nFeatSub must be a positive integer.');
end
if ~isscalar(config.timeDraw) || config.timeDraw < 1 || config.timeDraw ~= round(config.timeDraw)
    error('config.timeDraw must be a positive integer.');
end
if ~exist(config.outputDir, 'dir')
    mkdir(config.outputDir);
end
fprintf('=============================================================\n');
fprintf('   GROUP ANALYSIS: LDA Classification Across %d Subjects\n', config.numSubjects);
fprintf('   Using LOOCV with temporal buffer (±%d samples)\n', config.trainMinDistFromTest);
fprintf('   Vector mode: mean power features (matches paper)\n');
fprintf('   Random feature subsets: n = %d features, %d draws per subject\n', config.nFeatSub, config.timeDraw);
fprintf('=============================================================\n\n');
try
    pool = gcp('nocreate');
    if isempty(pool)
        fprintf('Starting parallel pool...\n');
        if isfield(config, 'numWorkers') && ~isempty(config.numWorkers) && config.numWorkers > 0
            numWorkers = min(config.numWorkers, feature('numcores'));
        else
            numWorkers = feature('numcores');
        end
        pool = parpool('local', numWorkers);
    end
    pool.IdleTimeout = 360;
    fprintf('Parallel pool ready: %d workers, IdleTimeout: %d min\n\n', ...
        pool.NumWorkers, pool.IdleTimeout);
catch ME
    warning('Parallel pool not available: %s\nRunning in serial mode.', ME.message);
    if exist('config', 'var')
        config.useParallel = false;
    end
end
hasSystemID = false;
if config.useLSSM || config.runBothMethods
    try
        if exist('n4sid', 'file') == 2 || exist('n4sid', 'file') == 6
            v = ver;
            toolboxNames = {v.Name};
            hasSystemID = any(contains(toolboxNames, 'System Identification Toolbox'));
            if hasSystemID
                try
                    testData = iddata(randn(10,1), [], 1);
                    clear testData;
                catch
                    hasSystemID = false;
                end
            end
        end
    catch
        hasSystemID = false;
    end
end
allAUC_LSSM = nan(config.numSubjects, 1);
allAcc_LSSM = nan(config.numSubjects, 1);
allSens_LSSM = nan(config.numSubjects, 1);
allSpec_LSSM = nan(config.numSubjects, 1);
allPPV_LSSM = nan(config.numSubjects, 1);
allPval_LSSM = nan(config.numSubjects, 1);
allLatentDim_LSSM = nan(config.numSubjects, 1);
allAUC_Vector = nan(config.numSubjects, 1);
allAcc_Vector = nan(config.numSubjects, 1);
allSens_Vector = nan(config.numSubjects, 1);
allSpec_Vector = nan(config.numSubjects, 1);
allPPV_Vector = nan(config.numSubjects, 1);
allPval_Vector = nan(config.numSubjects, 1);
allChanceAUC_LSSM = cell(config.numSubjects, 1);
allChanceAUC_Vector = cell(config.numSubjects, 1);
allFeatureWeightsNorm_LSSM = cell(config.numSubjects, 1);
allFeatureWeightsNorm_Vector = cell(config.numSubjects, 1);
allROC_LSSM = cell(config.numSubjects, 1);   % Each cell: struct with FPR, TPR
allROC_Vector = cell(config.numSubjects, 1);
validSubjects = true(config.numSubjects, 1);
allNumFeatures = nan(config.numSubjects, 1);                    % total features per subject (columns of inputdata)
allDrawFeat = cell(config.numSubjects, 1);                      % each cell: [timeDraw x nFeatSub] feature indices
allDrawAUC_LSSM = nan(config.numSubjects, config.timeDraw);     % AUC of every draw
allDrawAUC_Vector = nan(config.numSubjects, config.timeDraw);
fprintf('Loading and analyzing individual subjects...\n');
fprintf('-----------------------------------------------------------\n');
totalStartTime = tic;
progressQueue = [];
try
    progressQueue = parallel.pool.DataQueue;
    afterEach(progressQueue, @disp);
catch
    progressQueue = [];
end
useFastPerm = config.fastPermLDA && strcmp(config.predictor, 'LDA');
if isfield(config, 'ldaGamma') && ~isempty(config.ldaGamma) && isscalar(config.ldaGamma)
    fastGamma = config.ldaGamma;        
else
    fastGamma = 0;                     
end
allFastCheck = nan(config.numSubjects, 1);   
parfor si = 1:config.numSubjects
    subjStream = RandStream('mrg32k3a', 'Seed', config.randomSeed);
    subjStream.Substream = si;
    RandStream.setGlobalStream(subjStream);
    out = struct();
    out.valid = false;
    out.AUC_LSSM = NaN;
    out.Acc_LSSM = NaN;
    out.Sens_LSSM = NaN;
    out.Spec_LSSM = NaN;
    out.PPV_LSSM = NaN;
    out.pval_LSSM = NaN;
    out.latentDim_LSSM = NaN;
    out.chanceAUC_LSSM = [];
    out.featureWeightsNorm_LSSM = [];
    out.ROC_LSSM = [];
    out.AUC_Vector = NaN;
    out.Acc_Vector = NaN;
    out.Sens_Vector = NaN;
    out.Spec_Vector = NaN;
    out.PPV_Vector = NaN;
    out.pval_Vector = NaN;
    out.chanceAUC_Vector = [];
    out.featureWeightsNorm_Vector = [];
    out.ROC_Vector = [];
    out.numFeatures = NaN;
    out.drawFeat = [];
    out.drawAUC_LSSM = nan(1, config.timeDraw);
    out.drawAUC_Vector = nan(1, config.timeDraw);
    out.fastCheckMaxDiff = NaN;            
    subjTimer = tic;                        
    subjectOK = true;
    subjectFile = fullfile(config.dataDir, sprintf('%d.mat', si));
    if exist(subjectFile, 'file') ~= 2
        subjectOK = false;
    end
    if subjectOK
        try
            subjectData = load(subjectFile);
        catch
            subjectOK = false;
        end
    end
    if subjectOK && (~isfield(subjectData, 'inputdata') || ~isfield(subjectData, 'decodescore'))
        subjectOK = false;
    end
    if subjectOK
        inputdata = subjectData.inputdata;
        decodescore = subjectData.decodescore;
        if isempty(inputdata) || isempty(decodescore)
            subjectOK = false;
        end
    end
    if subjectOK
        numFeaturesAll = size(inputdata, 2);    % total features = columns of inputdata
        if config.nFeatSub > numFeaturesAll
            error('Subject %d: config.nFeatSub = %d exceeds the %d available features.', ...
                si, config.nFeatSub, numFeaturesAll);
        end
        drawFeat = zeros(config.timeDraw, config.nFeatSub);   % row di = feature indices of draw di
        for di = 1:config.timeDraw
            drawFeat(di, :) = sort(randperm(numFeaturesAll, config.nFeatSub));
        end
        out.numFeatures = numFeaturesAll;
        out.drawFeat = drawFeat;
    end
    if subjectOK
        for methodi = 1:2
            if methodi == 1
                methodTag = 'LSSM';
                runThisMethod = config.runBothMethods || config.useLSSM;
            else
                methodTag = 'Vector';
                runThisMethod = config.runBothMethods || ~config.useLSSM;
            end
            if ~runThisMethod
                continue;
            end
            useLSSMnow = (methodi == 1);
            try
                inputData = inputdata;
                painScores = decodescore;
                [numRecordings, numFeatures] = size(inputData);
                assert(iscell(inputData), 'inputData must be a cell array');
                assert(numel(painScores) == numRecordings, ...
                    'painScores length must match number of recordings');
                isValidCell = true(numRecordings, numFeatures);
                timePoints = zeros(numRecordings, numFeatures);
                for ri = 1:numRecordings
                    for fi = 1:numFeatures
                        cellVal = inputData{ri, fi};
                        isValidCell(ri, fi) = isnumeric(cellVal) && isvector(cellVal) && ~isempty(cellVal);
                        timePoints(ri, fi) = size(cellVal, 2);
                    end
                end
                if ~all(isValidCell(:))
                    error('Each element of inputData must be a non-empty numeric vector.');
                end
                if useLSSMnow
                    assert(all(timePoints(:) == timePoints(1, 1)), ...
                        'In LSSM mode, all time series must have the same number of time points.');
                else
                    if any(timePoints(:) == 0)
                        error('In Vector mode, each inputData cell must contain at least one time point.');
                    end
                end
                obsValid = ~isnan(painScores);
                if sum(~obsValid) > 0
                    warning('%d recordings with NaN pain scores will be excluded', sum(~obsValid));
                    inputData = inputData(obsValid, :);
                    painScores = painScores(obsValid);
                    numRecordings = sum(obsValid);
                end
                if numRecordings < 10
                    warning('Very few recordings (%d). Results may be unreliable.', numRecordings);
                end
                if numel(unique(painScores)) == 1
                    error('All pain scores are identical. Cannot perform classification.');
                end
                if ismember(config.predictor, {'logistic', 'SVM', 'LDA'})
                    uniqueVals = unique(painScores(~isnan(painScores)));
                    isAlreadyBinary = isequal(sort(uniqueVals(:)'), [0, 1]) || ...
                                      isequal(uniqueVals(:)', [0]) || ...
                                      isequal(uniqueVals(:)', [1]);
                    if isAlreadyBinary     
                        Y = double(painScores);
                    else
                        Y = double(painScores >= median(painScores));
                    end
                else
                    Y = zscore(painScores);
                end
                numPerm = config.numPermutations;
                permOrder = zeros(numPerm, length(Y));
                for permi = 1:numPerm
                    permOrder(permi, :) = randperm(length(Y));
                end
                if ~useLSSMnow
                    predictorsAll = zeros(numRecordings, numFeatures);
                    for ri = 1:numRecordings
                        for fi = 1:numFeatures
                            predictorsAll(ri, fi) = mean(inputData{ri, fi});
                        end
                    end
                    predictorsAll = zscore(predictorsAll);
                end
                rocGridFPR = linspace(0, 1, config.rocInterpolationPoints)';   % same FPR grid as STEP 3
                drawAUC = nan(1, config.timeDraw);
                drawAcc = nan(1, config.timeDraw);
                drawSens = nan(1, config.timeDraw);
                drawSpec = nan(1, config.timeDraw);
                drawPPV = nan(1, config.timeDraw);
                drawChance = nan(numPerm, config.timeDraw);                    % column di = chance AUCs of draw di
                drawTPR = nan(config.timeDraw, config.rocInterpolationPoints); % row di = ROC of draw di on rocGridFPR
                drawFW = nan(config.timeDraw, numFeatures);                    % Vector: weights placed at their feature index; NaN = not drawn
                drawFW_LSSM = cell(config.timeDraw, 1);                        % LSSM: weights over latent states
                drawLatentDim = nan(config.timeDraw, 1);
                drawFastDiff = nan(1, config.timeDraw);                      
                for di = 1:config.timeDraw
                    featIdx = drawFeat(di, :);
                    if useLSSMnow
                        inputSub = inputData(:, featIdx);
                        lsNumFeat = size(inputSub, 2);
                        lsNumTP = size(inputSub{1, 1}, 2);
                        allDataCat = zeros(numRecordings * lsNumTP, lsNumFeat);
                        for ri = 1:numRecordings
                            startIdx = (ri - 1) * lsNumTP + 1;
                            endIdx = ri * lsNumTP;
                            for fi = 1:lsNumFeat
                                allDataCat(startIdx:endIdx, fi) = inputSub{ri, fi}(:);
                            end
                        end
                        nanRows = any(isnan(allDataCat), 2);
                        if sum(nanRows) > 0
                            warning('Removing %d time points with NaN values', sum(nanRows));
                            allDataCat(nanRows, :) = [];
                        end
                        [allDataCat, lsMu, lsSigma] = zscore(allDataCat);
                        lsNy = size(allDataCat, 2);
                        horizon = config.lssmHorizon;
                        nxVals = unique([1, 2, 2:2:config.lssmMaxNx, config.lssmMaxNx]);
                        nxVals = sort(nxVals(nxVals >= 1 & nxVals <= config.lssmMaxNx));
                        lsAIC = nan(size(nxVals));
                        warnState = warning('off', 'all');
                        for nxi = 1:(numel(nxVals) + 1)
                            isFinalFit = nxi > numel(nxVals);
                            if isFinalFit
                                [~, selectedNxInd] = min(lsAIC);
                                nx = nxVals(selectedNxInd);
                            else
                                nx = nxVals(nxi);
                            end
                            try
                                if hasSystemID
                                    idData = iddata(allDataCat, [], 1);
                                    n4Opt = n4sidOptions(...
                                        'Focus', 'prediction', ...
                                        'N4Weight', 'auto', ...
                                        'N4Horizon', [horizon, horizon, horizon], ...
                                        'EnforceStability', true, ...
                                        'Display', 'off');
                                    try
                                        sys = n4sid(idData, nx, n4Opt);
                                    catch
                                        sys = n4sid(idData, nx, 'Ts', 1);
                                    end
                                    try
                                        [A, ~, C, ~, K] = idssdata(sys);
                                    catch
                                        A = sys.A;
                                        C = sys.C;
                                        if isprop(sys, 'K') && ~isempty(sys.K)
                                            K = sys.K;
                                        else
                                            K = [];    
                                        end
                                    end
                                    kgNx = nx;
                                    kgNoiseVar = sys.NoiseVariance;
                                    kgNeeded = isempty(K) || any(size(K) ~= [nx, lsNy]);
                                else
                                    [sidT, sidNy] = size(allDataCat);
                                    sidH = horizon;
                                    if sidH < 2, sidH = 2; end
                                    sidNx = nx;     % local copy: the reduced order below must not change nx
                                    if sidNx < 1, sidNx = 1; end
                                    numBlocks = sidT - 2*sidH + 1;
                                    if numBlocks < sidNx
                                        error('Not enough data. Reduce horizon or nx.');
                                    end
                                    Yp = zeros(sidH * sidNy, numBlocks);
                                    Yf = zeros(sidH * sidNy, numBlocks);
                                    for bi = 1:numBlocks
                                        for hj = 1:sidH
                                            Yp((hj-1)*sidNy + 1 : hj*sidNy, bi) = allDataCat(bi + hj - 1, :)';
                                            Yf((hj-1)*sidNy + 1 : hj*sidNy, bi) = allDataCat(bi + sidH + hj - 1, :)';
                                        end
                                    end
                                    combined = [Yf; Yp];
                                    [L, ~] = qr(combined', 0);
                                    L = L';
                                    rowsYf = 1:(sidH*sidNy);
                                    rowsYp = (sidH*sidNy + 1):(2*sidH*sidNy);
                                    L11 = L(rowsYf, 1:(sidH*sidNy));
                                    L21 = L(rowsYp, 1:(sidH*sidNy));
                                    L22 = L(rowsYp, (sidH*sidNy + 1):end);
                                    if rank(L22) > 0
                                        Ob = L11 - L21 * pinv(L22) * L(rowsYf, (sidH*sidNy + 1):end)';
                                        Ob = Ob * L21';
                                    else
                                        Ob = L11;
                                    end
                                    [U_svd, S_svd, ~] = svd(Ob, 'econ');
                                    sidNx = min(sidNx, size(S_svd, 1));
                                    sidNx = min(sidNx, sum(diag(S_svd) > 1e-10 * S_svd(1,1)));
                                    sidNx = max(sidNx, 1);
                                    Un = U_svd(:, 1:sidNx);
                                    Sn = S_svd(1:sidNx, 1:sidNx);
                                    Obs = Un * sqrt(Sn);
                                    C = Obs(1:sidNy, :);
                                    if size(Obs, 1) >= 2*sidNy
                                        Obs1 = Obs(1:end-sidNy, :);
                                        Obs2 = Obs(sidNy+1:end, :);
                                        A = pinv(Obs1) * Obs2;
                                    else
                                        A = eye(sidNx) * 0.95;
                                    end
                                    eigA = eig(A);
                                    maxEig = max(abs(eigA));
                                    if maxEig >= 1
                                        A = A / (maxEig + 0.01);
                                    end
                                    sidYhat = zeros(sidT, sidNy);
                                    sidX = zeros(sidNx, 1);
                                    for t = 1:sidT
                                        sidYhat(t, :) = (C * sidX)';
                                        sidX = A * sidX;
                                    end
                                    sidS = cov(allDataCat - sidYhat);
                                    sidS = (sidS + sidS') / 2;
                                    kgNx = sidNx;
                                    kgNoiseVar = sidS;
                                    kgNeeded = true;
                                end
                                if kgNeeded
                                    kgK = 0.01 * ones(kgNx, lsNy);      % K_default
                                    try
                                        if ~isempty(kgNoiseVar) && all(size(kgNoiseVar) == [lsNy, lsNy])
                                            kgR = (kgNoiseVar + kgNoiseVar') / 2;
                                            minEigR = min(eig(kgR));
                                            if minEigR < 1e-10
                                                kgR = kgR + eye(lsNy) * (1e-10 - minEigR + 1e-12);
                                            end
                                            kgQ = eye(kgNx) * trace(kgR) / lsNy * 0.01;
                                            kgP = eye(kgNx);
                                            for kgIter = 1:50
                                                kgPpred = A * kgP * A' + kgQ;
                                                kgPpred = (kgPpred + kgPpred') / 2;
                                                kgS = C * kgPpred * C' + kgR;
                                                kgS = (kgS + kgS') / 2;
                                                condS = rcond(kgS);
                                                if condS < 1e-12 || isnan(condS)
                                                    kgS = kgS + eye(lsNy) * 1e-8;
                                                end
                                                try
                                                    kgKcalc = kgPpred * C' / kgS;
                                                catch
                                                    kgKcalc = kgPpred * C' * pinv(kgS);
                                                end
                                                kgP = kgPpred - kgKcalc * C * kgPpred;
                                                kgP = (kgP + kgP') / 2;
                                                minEigP = min(eig(kgP));
                                                if minEigP < 1e-12
                                                    kgP = kgP + eye(kgNx) * (1e-12 - minEigP);
                                                end
                                            end
                                            kgKcalc = max(min(kgKcalc, 10), -10);
                                            if ~any(isnan(kgKcalc(:))) && ~any(isinf(kgKcalc(:)))
                                                kgK = kgKcalc;
                                            end
                                        end
                                    catch
                                        kgK = 0.01 * ones(kgNx, lsNy);
                                    end
                                    K = kgK;
                                end
                                if ~isFinalFit
                                    kfX = zeros(size(A, 1), 1);
                                    kfYhat = zeros(size(allDataCat, 1), lsNy);
                                    for t = 1:size(allDataCat, 1)
                                        kfYpred = C * kfX;
                                        kfYhat(t, :) = kfYpred';
                                        kfX = A * kfX + K * (allDataCat(t, :)' - kfYpred);
                                    end
                                    numParams = (2 * lsNy + 1) * nx;
                                    aicResid = allDataCat - kfYhat;
                                    aicN = numel(allDataCat);
                                    aicRSS = sum(aicResid(:).^2);
                                    logLik = -aicN/2 * log(2*pi) - aicN/2 * log(aicRSS/aicN) - aicN/2;
                                    lsAIC(nxi) = 2 * numParams - 2 * logLik;
                                end
                            catch ME_lssm
                                if isFinalFit
                                    warning(warnState);
                                    rethrow(ME_lssm);
                                end
                                lsAIC(nxi) = Inf;
                            end
                        end
                        warning(warnState);
                        lsPredictors = zeros(numRecordings, nx);
                        for ri = 1:numRecordings
                            yRec = zeros(lsNumTP, lsNumFeat);
                            for fi = 1:lsNumFeat
                                yRec(:, fi) = inputSub{ri, fi}(:);
                            end
                            yRec = (yRec - lsMu) ./ lsSigma;
                            kfX = zeros(size(A, 1), 1);
                            for t = 1:lsNumTP
                                kfYpred = C * kfX;
                                kfX = A * kfX + K * (yRec(t, :)' - kfYpred);
                            end
                            lsPredictors(ri, :) = kfX';
                        end
                        % Z-score normalize predictors
                        X = zscore(lsPredictors);
                        drawLatentDim(di) = nx;
                    else
                        % Vector: drawn columns of the z-scored mean-power matrix
                        X = predictorsAll(:, featIdx);
                    end
                    for permi = 0:numPerm
                        if permi == 0
                            Ycv = Y;
                        else
                            Ycv = Y(permOrder(permi, :));
                        end
                        fastAUC = NaN;
                        if useFastPerm
                            flN = size(X, 1);
                            flY = Ycv(:);
                            if isempty(config.numFolds)
                                flNumFolds = flN;       % LOOCV (temporal buffer applied below, as in the original)
                            else
                                flNumFolds = config.numFolds;
                                foldID = zeros(flN, 1);
                                flOff = 0;
                                for flCls = 0:1
                                    flIdx = find(flY == flCls);
                                    flIdx = flIdx(randperm(numel(flIdx)));
                                    foldID(flIdx) = mod(flOff + (0:numel(flIdx)-1)', flNumFolds) + 1;
                                    flOff = flOff + numel(flIdx);
                                end
                            end
                            flD = nan(flN, 1);
                            try
                                for fold = 1:flNumFolds
                                    if isempty(config.numFolds)
                                        flTe = fold;
                                        flTr = true(flN, 1);
                                        flTr(max(1, fold - config.trainMinDistFromTest) : ...
                                             min(flN, fold + config.trainMinDistFromTest)) = false;
                                    else
                                        flTe = find(foldID == fold);
                                        flTr = foldID ~= fold;
                                    end
                                    flXtr = X(flTr, :);
                                    flC1 = flY(flTr) == 1;
                                    flN1 = sum(flC1);
                                    flN0 = numel(flC1) - flN1;
                                    if flN1 == 0 || flN0 == 0
                                        continue;       % same skip rule as the original fold loop
                                    end
                                    flM1 = sum(flXtr(flC1, :), 1) / flN1;
                                    flM0 = sum(flXtr(~flC1, :), 1) / flN0;
                                    flR = flXtr - double(flC1) * flM1 - double(~flC1) * flM0;   % each row minus its class mean
                                    flS = (flR' * flR) / (flN1 + flN0 - 2);
                                    if any(diag(flS) <= 0)
                                        error('Zero within-class variance.');   % fitcdiscr fails here too
                                    end
                                    flSg = (1 - fastGamma) * flS + fastGamma * diag(diag(flS));
                                    flD(flTe) = log(flN1 / flN0) + ...
                                        (X(flTe, :) - (flM1 + flM0) / 2) * (flSg \ (flM1 - flM0)');
                                end
                                flValid = ~isnan(flD);
                                flYv = flY(flValid);
                                flNP = sum(flYv == 1);
                                flNN = sum(flYv == 0);
                                if flNP > 0 && flNN > 0
                                    flRank = tiedrank(flD(flValid));
                                    fastAUC = (sum(flRank(flYv == 1)) - flNP * (flNP + 1) / 2) / (flNP * flNN);
                                else
                                    fastAUC = 0.5;      % same rule as the original (one class left)
                                end
                            catch
                                fastAUC = 0.5;          % failed CV counts as chance (as in the original)
                            end
                            if permi > 0
                                drawChance(permi, di) = fastAUC;
                                continue;               % permuted labels done
                            end
                        end

                        try
                            numSamples = size(X, 1);
                            numFeatCV = size(X, 2);
                            % Determine CV scheme
                            if isempty(config.numFolds)
                                numFolds = numSamples;  % LOOCV
                                isLOOCV = true;
                            else
                                numFolds = config.numFolds;
                                if ~useFastPerm
                                    cvPart = cvpartition(Ycv, 'KFold', numFolds);
                                end                    
                                isLOOCV = false;
                            end
                            predictions = nan(numSamples, 1);
                            scores = nan(numSamples, 1);
                            featureWeightsAllFolds = nan(numFolds, numFeatCV);
                            for fold = 1:numFolds
                                if isLOOCV
                                    testIdx = fold;
                                    trainIdx = setdiff(1:numSamples, testIdx);
                                    if config.trainMinDistFromTest > 0
                                        bufferRange = max(1, testIdx - config.trainMinDistFromTest) : ...
                                                      min(numSamples, testIdx + config.trainMinDistFromTest);
                                        trainIdx = setdiff(trainIdx, bufferRange);
                                    end
                                else
                                    % K-fold
                                    if useFastPerm
                                        testIdx = find(foldID == fold);     
                                        trainIdx = find(foldID ~= fold);
                                    else
                                        testIdx = find(test(cvPart, fold));
                                        trainIdx = find(training(cvPart, fold));
                                    end
                                end
                                if isempty(trainIdx) || length(unique(Ycv(trainIdx))) < 2
                                    continue;
                                end
                                % Per-fold normalization: fit on train only, apply to train and test (avoids data leakage)
                                mu = mean(X(trainIdx, :), 1);
                                sigma = std(X(trainIdx, :), 0, 1) + eps;
                                XTrain = (X(trainIdx, :) - mu) ./ sigma;
                                XTest = (X(testIdx, :) - mu) ./ sigma;
                                YTrain = Ycv(trainIdx);
                                % Train classifier
                                switch config.predictor
                                    case 'LDA'
                                        useGamma = isfield(config, 'ldaGamma') && ~isempty(config.ldaGamma) && isscalar(config.ldaGamma);
                                        if useGamma
                                            model = fitcdiscr(XTrain, YTrain, 'DiscrimType', 'linear', 'Gamma', config.ldaGamma);
                                        else
                                            try
                                                model = fitcdiscr(XTrain, YTrain, 'DiscrimType', 'linear');
                                            catch
                                                model = fitcdiscr(XTrain, YTrain, 'DiscrimType', 'linear', 'Gamma', 1);
                                            end
                                        end
                                        [pred, score] = predict(model, XTest);
                                        predictions(testIdx) = pred;
                                        if size(score, 2) >= 2
                                            scores(testIdx) = score(:, 2);
                                        else
                                            scores(testIdx) = score(:, 1);
                                        end
                                        if ~isempty(model.Coeffs) && numel(model.Coeffs) >= 2
                                            featureWeightsAllFolds(fold, :) = model.Coeffs(1,2).Linear';
                                        end
                                    case 'SVM'
                                        model = fitcsvm(XTrain, YTrain, 'KernelFunction', 'linear', 'Standardize', true);
                                        [pred, score] = predict(model, XTest);
                                        predictions(testIdx) = pred;
                                        scores(testIdx) = score(:, 2);
                                        if isprop(model, 'Beta') && ~isempty(model.Beta)
                                            featureWeightsAllFolds(fold, :) = model.Beta';
                                        end
                                    case 'logistic'
                                        model = fitglm(XTrain, YTrain, 'Distribution', 'binomial');
                                        prob = predict(model, XTest);
                                        predictions(testIdx) = prob >= 0.5;
                                        scores(testIdx) = prob;
                                        coeffs = model.Coefficients.Estimate;
                                        if length(coeffs) > 1
                                            featureWeightsAllFolds(fold, :) = coeffs(2:end)';
                                        end
                                    case 'ridge'
                                        b = ridge(YTrain, XTrain, 1, 0);
                                        pred = [ones(size(XTest,1),1), XTest] * b;
                                        predictions(testIdx) = pred >= 0;
                                        scores(testIdx) = pred;
                                        if length(b) > 1
                                            featureWeightsAllFolds(fold, :) = b(2:end)';
                                        end
                                end
                            end
                            % Calculate metrics
                            cvValid = ~isnan(predictions);
                            Y_valid = Ycv(cvValid);
                            pred_valid = predictions(cvValid);
                            scores_valid = scores(cvValid);
                            TP = sum(pred_valid == 1 & Y_valid == 1);
                            TN = sum(pred_valid == 0 & Y_valid == 0);
                            FP = sum(pred_valid == 1 & Y_valid == 0);
                            FN = sum(pred_valid == 0 & Y_valid == 1);
                            cvAcc = (TP + TN) / (TP + TN + FP + FN);
                            cvSens = TP / (TP + FN + eps);
                            cvSpec = TN / (TN + FP + eps);
                            cvPPV = TP / (TP + FP + eps);
                            % Calculate AUC and ROC curve data
                            if numel(unique(Y_valid)) > 1 && ~all(isnan(scores_valid))
                                try
                                    % perfcurve returns [X, Y, T, AUC] where X=FPR, Y=TPR, T=thresholds
                                    [ROC_FPR, ROC_TPR, ~, cvAUC] = perfcurve(Y_valid, scores_valid, 1);
                                    if numel(cvAUC) > 1
                                        cvAUC = cvAUC(1);
                                    end
                                    cvFPR = ROC_FPR(:);     % False Positive Rate (1 - Specificity)
                                    cvTPR = ROC_TPR(:);     % True Positive Rate (Sensitivity)
                                catch
                                    cvAUC = 0.5;
                                    cvFPR = [0; 1];
                                    cvTPR = [0; 1];
                                end
                            else
                                cvAUC = 0.5;
                                cvFPR = [0; 1];
                                cvTPR = [0; 1];
                            end
                        catch ME_cv
                            if permi == 0
                                rethrow(ME_cv);     % true-label CV failure -> this method fails for this subject (as before)
                            end
                            cvAUC = 0.5;            % failed permutation counts as chance (as before)
                        end

                        if permi == 0
                            drawAUC(di) = cvAUC;
                            drawAcc(di) = cvAcc;
                            drawSens(di) = cvSens;
                            drawSpec(di) = cvSpec;
                            drawPPV(di) = cvPPV;
                            if useFastPerm
                                drawFastDiff(di) = abs(fastAUC - cvAUC);    % [SPEED] expected ~0
                            end
                            [drFPRu, ~, drIc] = unique(cvFPR);
                            drTPRu = accumarray(drIc, cvTPR, [], @mean);
                            if drFPRu(1) > 0
                                drFPRu = [0; drFPRu];
                                drTPRu = [0; drTPRu];
                            elseif drFPRu(1) == 0
                                drTPRu(1) = 0;
                            end
                            if drFPRu(end) < 1
                                drFPRu = [drFPRu; 1];
                                drTPRu = [drTPRu; 1];
                            elseif drFPRu(end) == 1
                                drTPRu(end) = 1;
                            end
                            if length(drFPRu) >= 2
                                drTPRgrid = interp1(drFPRu, drTPRu, rocGridFPR, 'linear');
                            else
                                drTPRgrid = repmat(drTPRu(1), size(rocGridFPR));
                            end
                            drawTPR(di, :) = max(0, min(1, drTPRgrid(:)'));
                            % Feature weights (mean over folds, scaled by max |weight|)
                            meanFeatureWeights = mean(featureWeightsAllFolds, 1, 'omitnan');
                            maxAbsWeight = max(abs(meanFeatureWeights));
                            if maxAbsWeight > 0
                                normalizedFeatureWeights = meanFeatureWeights / maxAbsWeight;
                            else
                                normalizedFeatureWeights = meanFeatureWeights;
                            end
                            if useLSSMnow
                                drawFW_LSSM{di} = normalizedFeatureWeights(:)';
                            else
                                drawFW(di, featIdx) = normalizedFeatureWeights;
                            end
                        else
                            drawChance(permi, di) = cvAUC;
                        end
                    end
                    % [SPEED] progress line
                    if config.progressEvery > 0 && mod(di, config.progressEvery) == 0 && ~isempty(progressQueue)
                        send(progressQueue, sprintf('  Subject %02d (%s): %d/%d draws, %.1f min', ...
                            si, methodTag, di, config.timeDraw, toc(subjTimer) / 60));
                    end
                end
                mAUC = mean(drawAUC);
                mChance = mean(drawChance, 2);                         % [numPerm x 1] null of the draw-averaged AUC
                mPval = (sum(mChance >= mAUC) + 1) / (numPerm + 1);    % empirical p-value (formerly performPermutationTest)
                mTPR = mean(drawTPR, 1);
                if useLSSMnow
                    if all(drawLatentDim == drawLatentDim(1))
                        mFW = mean(cell2mat(drawFW_LSSM), 1);
                    else
                        mFW = [];
                    end
                    out.latentDim_LSSM = mode(drawLatentDim);
                else
                    mFW = mean(drawFW, 1, 'omitnan');                  % per feature: mean over the draws that included it
                end
                out.(['AUC_' methodTag]) = mAUC;
                out.(['Acc_' methodTag]) = mean(drawAcc);
                out.(['Sens_' methodTag]) = mean(drawSens);
                out.(['Spec_' methodTag]) = mean(drawSpec);
                out.(['PPV_' methodTag]) = mean(drawPPV);
                out.(['pval_' methodTag]) = mPval;
                out.(['chanceAUC_' methodTag]) = mChance;
                out.(['featureWeightsNorm_' methodTag]) = mFW(:)';
                out.(['ROC_' methodTag]) = struct('FPR', rocGridFPR, ...
                                                 'TPR', mTPR(:), ...
                                                 'AUC', mAUC);
                out.(['drawAUC_' methodTag]) = drawAUC;
                out.fastCheckMaxDiff = max([out.fastCheckMaxDiff, drawFastDiff]);   % [SPEED] max ignores NaN
            catch
                out.(['AUC_' methodTag]) = NaN;
            end
        end
        out.valid = true;
        if ~isempty(progressQueue)        
            send(progressQueue, sprintf('Subject %02d finished in %.1f min (AUC LSSM %.3f, Vector %.3f)', ...
                si, toc(subjTimer) / 60, out.AUC_LSSM, out.AUC_Vector));
        end
    end
    validSubjects(si) = out.valid;
    allAUC_LSSM(si) = out.AUC_LSSM;
    allAcc_LSSM(si) = out.Acc_LSSM;
    allSens_LSSM(si) = out.Sens_LSSM;
    allSpec_LSSM(si) = out.Spec_LSSM;
    allPPV_LSSM(si) = out.PPV_LSSM;
    allPval_LSSM(si) = out.pval_LSSM;
    allLatentDim_LSSM(si) = out.latentDim_LSSM;
    allChanceAUC_LSSM{si} = out.chanceAUC_LSSM;
    allFeatureWeightsNorm_LSSM{si} = out.featureWeightsNorm_LSSM;
    allROC_LSSM{si} = out.ROC_LSSM;
    allAUC_Vector(si) = out.AUC_Vector;
    allAcc_Vector(si) = out.Acc_Vector;
    allSens_Vector(si) = out.Sens_Vector;
    allSpec_Vector(si) = out.Spec_Vector;
    allPPV_Vector(si) = out.PPV_Vector;
    allPval_Vector(si) = out.pval_Vector;
    allChanceAUC_Vector{si} = out.chanceAUC_Vector;
    allFeatureWeightsNorm_Vector{si} = out.featureWeightsNorm_Vector;
    allROC_Vector{si} = out.ROC_Vector;
    allNumFeatures(si) = out.numFeatures;
    allDrawFeat{si} = out.drawFeat;
    allDrawAUC_LSSM(si, :) = out.drawAUC_LSSM;
    allDrawAUC_Vector(si, :) = out.drawAUC_Vector;
    allFastCheck(si) = out.fastCheckMaxDiff;   
end
totalTime = toc(totalStartTime);
fprintf('-----------------------------------------------------------\n');
for si = 1:config.numSubjects
    if validSubjects(si) && ~isnan(allAUC_LSSM(si)) && ~isnan(allAUC_Vector(si))
        fprintf('Subject %02d: LSSM:%.3f Vec:%.3f\n', si, allAUC_LSSM(si), allAUC_Vector(si));
    elseif ~validSubjects(si)
        fprintf('Subject %02d: skipped (file missing or invalid)\n', si);
    else
        fprintf('Subject %02d: LSSM:%.3f Vec:%.3f (one or both failed)\n', si, allAUC_LSSM(si), allAUC_Vector(si));
    end
end
for si = 1:config.numSubjects
    if validSubjects(si) && ~isempty(allDrawFeat{si})
        numUndrawn = numel(setdiff(1:allNumFeatures(si), allDrawFeat{si}(:)));
        if numUndrawn > 0
            fprintf('Subject %02d: %d of %d features never drawn in %d draws\n', ...
                si, numUndrawn, allNumFeatures(si), config.timeDraw);
        end
    end
end
fprintf('-----------------------------------------------------------\n');
fprintf('Completed: %d / %d subjects in %.1f min\n\n', ...
    sum(validSubjects), config.numSubjects, totalTime/60);
if useFastPerm
    fprintf('Fast-permutation check: max |closed-form AUC - fitcdiscr AUC| = %.2e\n', max(allFastCheck));
    if max(allFastCheck) > 1e-6
        fprintf('  WARNING: above 1e-6. Rerun one subject with config.fastPermLDA = false and compare.\n');
    end
    fprintf('\n');
end
rng(config.randomSeed, 'twister');
fprintf('=============================================================\n');
fprintf('   GROUP-LEVEL STATISTICAL ANALYSIS\n');
fprintf('=============================================================\n\n');
hasLSSM = any(validSubjects & ~isnan(allAUC_LSSM));
hasVector = any(validSubjects & ~isnan(allAUC_Vector));
if hasLSSM && hasVector
    validIdx = validSubjects & ~isnan(allAUC_LSSM) & ~isnan(allAUC_Vector);
elseif hasVector
    validIdx = validSubjects & ~isnan(allAUC_Vector);
elseif hasLSSM
    validIdx = validSubjects & ~isnan(allAUC_LSSM);
else
    error('No valid decoding results available for group analysis.');
end
numValidSubjects = sum(validIdx);
fprintf('Valid subjects for group analysis: %d\n', numValidSubjects);
fprintf('  LSSM available: %s\n', string(hasLSSM));
fprintf('  Vector available: %s\n\n', string(hasVector));
validAUC_LSSM = allAUC_LSSM(validIdx);
validAUC_Vector = allAUC_Vector(validIdx);
validChanceAUC_LSSM = allChanceAUC_LSSM(validIdx);
validChanceAUC_Vector = allChanceAUC_Vector(validIdx);
validROC_LSSM = allROC_LSSM(validIdx);
validROC_Vector = allROC_Vector(validIdx);
groupResults = struct();
groupResults.config = config;
groupResults.numValidSubjects = numValidSubjects;
groupResults.validSubjectIndices = find(validIdx);
fprintf('--- Descriptive Statistics ---\n\n');
groupResults.LSSM = struct();
groupResults.Vector = struct();
if hasLSSM
    groupResults.LSSM.AUC_mean = mean(validAUC_LSSM);
    groupResults.LSSM.AUC_std = std(validAUC_LSSM);
    groupResults.LSSM.AUC_median = median(validAUC_LSSM);
    groupResults.LSSM.AUC_sem = std(validAUC_LSSM) / sqrt(numValidSubjects);
    groupResults.LSSM.Accuracy_mean = mean(allAcc_LSSM(validIdx));
    groupResults.LSSM.Sensitivity_mean = mean(allSens_LSSM(validIdx));
    groupResults.LSSM.Specificity_mean = mean(allSpec_LSSM(validIdx));
    groupResults.LSSM.PPV_mean = mean(allPPV_LSSM(validIdx));
    fprintf('LSSM + LDA:\n');
    fprintf('  AUC: %.3f ± %.3f (median: %.3f)\n', ...
        groupResults.LSSM.AUC_mean, groupResults.LSSM.AUC_std, groupResults.LSSM.AUC_median);
    fprintf('  Accuracy: %.1f%%, Sens/Spec/PPV: %.3f/%.3f/%.3f\n\n', ...
        groupResults.LSSM.Accuracy_mean*100, groupResults.LSSM.Sensitivity_mean, ...
        groupResults.LSSM.Specificity_mean, groupResults.LSSM.PPV_mean);
else
    groupResults.LSSM.note = 'LSSM decoding disabled or no valid LSSM results.';
end
if hasVector
    groupResults.Vector.AUC_mean = mean(validAUC_Vector);
    groupResults.Vector.AUC_std = std(validAUC_Vector);
    groupResults.Vector.AUC_median = median(validAUC_Vector);
    groupResults.Vector.AUC_sem = std(validAUC_Vector) / sqrt(numValidSubjects);
    groupResults.Vector.Accuracy_mean = mean(allAcc_Vector(validIdx));
    groupResults.Vector.Sensitivity_mean = mean(allSens_Vector(validIdx));
    groupResults.Vector.Specificity_mean = mean(allSpec_Vector(validIdx));
    groupResults.Vector.PPV_mean = mean(allPPV_Vector(validIdx));
    fprintf('Vector + LDA (mean power):\n');
    fprintf('  AUC: %.3f ± %.3f (median: %.3f)\n', ...
        groupResults.Vector.AUC_mean, groupResults.Vector.AUC_std, groupResults.Vector.AUC_median);
    fprintf('  Accuracy: %.1f%%, Sens/Spec/PPV: %.3f/%.3f/%.3f\n\n', ...
        groupResults.Vector.Accuracy_mean*100, groupResults.Vector.Sensitivity_mean, ...
        groupResults.Vector.Specificity_mean, groupResults.Vector.PPV_mean);
else
    groupResults.Vector.note = 'Vector decoding not available.';
end
fprintf('--- Group Permutation Tests (%d permutations) ---\n\n', config.groupNumPermutations);
if hasLSSM
    fprintf('Running LSSM sign-flipping test...\n');
    gpData = validAUC_LSSM;
    gpNullMean = 0.5;                   % chance-level AUC
    gpN = length(gpData);
    gpObservedMean = mean(gpData);
    gpCentered = gpData - gpNullMean;
    gpExceed = 0;
    gpNullSum = 0;
    gpNullSumSq = 0;
    for permi = 1:config.groupNumPermutations
        gpSigns = 2 * (rand(gpN, 1) > 0.5) - 1;
        gpPermMean = mean(gpNullMean + gpSigns .* abs(gpCentered));
        if gpPermMean >= gpObservedMean
            gpExceed = gpExceed + 1;
        end
        gpNullSum = gpNullSum + gpPermMean;
        gpNullSumSq = gpNullSumSq + gpPermMean^2;
    end
    groupResults.LSSM.permutation = struct();
    groupResults.LSSM.permutation.pValue = (gpExceed + 1) / (config.groupNumPermutations + 1);
    groupResults.LSSM.permutation.observedMean = gpObservedMean;
    groupResults.LSSM.permutation.nullMean = gpNullSum / config.groupNumPermutations;
    groupResults.LSSM.permutation.nullStd = sqrt((gpNullSumSq / config.groupNumPermutations) - (gpNullSum / config.groupNumPermutations)^2);
    fprintf('  p-value: %.6f (sig: %s)\n\n', groupResults.LSSM.permutation.pValue, ...
        string(groupResults.LSSM.permutation.pValue < config.alphaLevel));
end
if hasVector
    fprintf('Running Vector sign-flipping test...\n');
    gpData = validAUC_Vector;
    gpNullMean = 0.5;                   % chance-level AUC
    gpN = length(gpData);
    gpObservedMean = mean(gpData);
    gpCentered = gpData - gpNullMean;
    gpExceed = 0;
    gpNullSum = 0;
    gpNullSumSq = 0;
    for permi = 1:config.groupNumPermutations
        gpSigns = 2 * (rand(gpN, 1) > 0.5) - 1;
        gpPermMean = mean(gpNullMean + gpSigns .* abs(gpCentered));
        if gpPermMean >= gpObservedMean
            gpExceed = gpExceed + 1;
        end
        gpNullSum = gpNullSum + gpPermMean;
        gpNullSumSq = gpNullSumSq + gpPermMean^2;
    end
    groupResults.Vector.permutation = struct();
    groupResults.Vector.permutation.pValue = (gpExceed + 1) / (config.groupNumPermutations + 1);
    groupResults.Vector.permutation.observedMean = gpObservedMean;
    groupResults.Vector.permutation.nullMean = gpNullSum / config.groupNumPermutations;
    groupResults.Vector.permutation.nullStd = sqrt((gpNullSumSq / config.groupNumPermutations) - (gpNullSum / config.groupNumPermutations)^2);
    fprintf('  p-value: %.6f (sig: %s)\n\n', groupResults.Vector.permutation.pValue, ...
        string(groupResults.Vector.permutation.pValue < config.alphaLevel));
end
fprintf('Running pooled permutation tests...\n');
if hasLSSM
    ppObserved = validAUC_LSSM;
    ppChance = validChanceAUC_LSSM;
    ppN = length(ppObserved);
    ppObservedMean = mean(ppObserved);
    ppNumPermsPerSubject = cellfun(@length, ppChance);
    ppExceed = 0;
    ppNullSum = 0;
    ppNullSumSq = 0;
    for permi = 1:config.groupNumPermutations
        ppSampled = zeros(ppN, 1);
        for ppsi = 1:ppN
            if ~isempty(ppChance{ppsi}) && ppNumPermsPerSubject(ppsi) > 0
                ppRandIdx = randi(ppNumPermsPerSubject(ppsi));
                ppSampled(ppsi) = ppChance{ppsi}(ppRandIdx);
            else
                ppSampled(ppsi) = 0.5;
            end
        end
        ppPermMean = mean(ppSampled);
        if ppPermMean >= ppObservedMean
            ppExceed = ppExceed + 1;
        end
        ppNullSum = ppNullSum + ppPermMean;
        ppNullSumSq = ppNullSumSq + ppPermMean^2;
    end
    groupResults.LSSM.pooledPermutation = struct();
    groupResults.LSSM.pooledPermutation.pValue = (ppExceed + 1) / (config.groupNumPermutations + 1);
    groupResults.LSSM.pooledPermutation.observedMean = ppObservedMean;
    groupResults.LSSM.pooledPermutation.nullMean = ppNullSum / config.groupNumPermutations;
    groupResults.LSSM.pooledPermutation.nullStd = sqrt((ppNullSumSq / config.groupNumPermutations) - (ppNullSum / config.groupNumPermutations)^2);
    fprintf('  LSSM pooled p-value: %.6f\n', groupResults.LSSM.pooledPermutation.pValue);
end
if hasVector
    ppObserved = validAUC_Vector;
    ppChance = validChanceAUC_Vector;
    ppN = length(ppObserved);
    ppObservedMean = mean(ppObserved);
    ppNumPermsPerSubject = cellfun(@length, ppChance);
    ppExceed = 0;
    ppNullSum = 0;
    ppNullSumSq = 0;
    for permi = 1:config.groupNumPermutations
        ppSampled = zeros(ppN, 1);
        for ppsi = 1:ppN
            if ~isempty(ppChance{ppsi}) && ppNumPermsPerSubject(ppsi) > 0
                ppRandIdx = randi(ppNumPermsPerSubject(ppsi));
                ppSampled(ppsi) = ppChance{ppsi}(ppRandIdx);
            else
                ppSampled(ppsi) = 0.5;
            end
        end
        ppPermMean = mean(ppSampled);
        if ppPermMean >= ppObservedMean
            ppExceed = ppExceed + 1;
        end
        ppNullSum = ppNullSum + ppPermMean;
        ppNullSumSq = ppNullSumSq + ppPermMean^2;
    end
    groupResults.Vector.pooledPermutation = struct();
    groupResults.Vector.pooledPermutation.pValue = (ppExceed + 1) / (config.groupNumPermutations + 1);
    groupResults.Vector.pooledPermutation.observedMean = ppObservedMean;
    groupResults.Vector.pooledPermutation.nullMean = ppNullSum / config.groupNumPermutations;
    groupResults.Vector.pooledPermutation.nullStd = sqrt((ppNullSumSq / config.groupNumPermutations) - (ppNullSum / config.groupNumPermutations)^2);
    fprintf('  Vector pooled p-value: %.6f\n\n', groupResults.Vector.pooledPermutation.pValue);
end
fprintf('--- LSSM vs Vector Comparison ---\n\n');
if hasLSSM && hasVector
    aucDiff = validAUC_LSSM - validAUC_Vector;
    ptN = length(aucDiff);
    ptObservedMean = mean(aucDiff);
    ptAbsObserved = abs(ptObservedMean);
    ptExceed = 0;
    for permi = 1:config.groupNumPermutations
        ptSigns = 2 * (rand(ptN, 1) > 0.5) - 1;
        ptPermMean = mean(ptSigns .* aucDiff);
        if abs(ptPermMean) >= ptAbsObserved
            ptExceed = ptExceed + 1;
        end
    end
    groupResults.comparison = struct();
    groupResults.comparison.pValue = (ptExceed + 1) / (config.groupNumPermutations + 1);
    groupResults.comparison.observedMean = ptObservedMean;
    fprintf('AUC diff (LSSM - Vector): %.4f ± %.4f\n', mean(aucDiff), std(aucDiff));
    fprintf('Paired permutation p-value: %.6f\n\n', groupResults.comparison.pValue);
else
    aucDiff = [];
    groupResults.comparison = [];
    fprintf('LSSM vs Vector comparison skipped (one or both methods unavailable).\n\n');
end
numSig_LSSM = sum(allPval_LSSM(validIdx) < config.alphaLevel);
numSig_Vector = sum(allPval_Vector(validIdx) < config.alphaLevel);
groupResults.LSSM.numSignificantSubjects = [];
groupResults.Vector.numSignificantSubjects = [];
fprintf('Individual significance (p < %.2f):\n', config.alphaLevel);
if hasLSSM
    groupResults.LSSM.numSignificantSubjects = numSig_LSSM;
    fprintf('  LSSM: %d/%d (%.1f%%)\n', numSig_LSSM, numValidSubjects, 100*numSig_LSSM/numValidSubjects);
end
if hasVector
    groupResults.Vector.numSignificantSubjects = numSig_Vector;
    fprintf('  Vector: %d/%d (%.1f%%)\n\n', numSig_Vector, numValidSubjects, 100*numSig_Vector/numValidSubjects);
end
fprintf('=============================================================\n');
fprintf('   ROC CURVE ANALYSIS\n');
fprintf('=============================================================\n\n');
fprintf('Computing mean ROC curves...\n');
commonFPR = linspace(0, 1, config.rocInterpolationPoints)';
groupResults.ROC = struct();
groupResults.ROC.commonFPR = commonFPR;
if hasLSSM
    interpTPR_LSSM = nan(numValidSubjects, config.rocInterpolationPoints);
    for si = 1:numValidSubjects
        if ~isempty(validROC_LSSM{si})
            fpr = validROC_LSSM{si}.FPR;
            tpr = validROC_LSSM{si}.TPR;
            [fpr_unique, ~, ic] = unique(fpr);
            tpr_unique = accumarray(ic, tpr, [], @mean);
            if fpr_unique(1) > 0
                fpr_unique = [0; fpr_unique];
                tpr_unique = [0; tpr_unique];
            elseif fpr_unique(1) == 0
                tpr_unique(1) = 0;
            end
            if fpr_unique(end) < 1
                fpr_unique = [fpr_unique; 1];
                tpr_unique = [tpr_unique; 1];
            elseif fpr_unique(end) == 1
                tpr_unique(end) = 1;
            end
            % Interpolate TPR at common FPR points
            if length(fpr_unique) >= 2
                interpTPR_LSSM(si, :) = interp1(fpr_unique, tpr_unique, ...
                    commonFPR, 'linear');
            else
                % If only one unique point, use constant
                interpTPR_LSSM(si, :) = tpr_unique(1);
            end
            % Ensure bounds [0, 1]
            interpTPR_LSSM(si, :) = max(0, min(1, interpTPR_LSSM(si, :)));
        end
    end
    meanTPR_LSSM = mean(interpTPR_LSSM, 1, 'omitnan');
    stdTPR_LSSM = std(interpTPR_LSSM, 0, 1, 'omitnan');
    semTPR_LSSM = stdTPR_LSSM / sqrt(numValidSubjects);
    groupResults.ROC.LSSM.meanTPR = meanTPR_LSSM;
    groupResults.ROC.LSSM.stdTPR = stdTPR_LSSM;
    groupResults.ROC.LSSM.semTPR = semTPR_LSSM;
    groupResults.ROC.LSSM.allTPR = interpTPR_LSSM;
    groupResults.ROC.LSSM.individualCurves = validROC_LSSM;
    fprintf('  LSSM mean AUC: %.3f ± %.3f\n', groupResults.LSSM.AUC_mean, groupResults.LSSM.AUC_std);
end
if hasVector
    interpTPR_Vector = nan(numValidSubjects, config.rocInterpolationPoints);
    for si = 1:numValidSubjects
        if ~isempty(validROC_Vector{si})
            fpr = validROC_Vector{si}.FPR;
            tpr = validROC_Vector{si}.TPR;
            % Handle duplicate FPR values by averaging corresponding TPR values
            [fpr_unique, ~, ic] = unique(fpr);
            tpr_unique = accumarray(ic, tpr, [], @mean);
            % Ensure ROC curve is anchored at (0,0) and (1,1)
            if fpr_unique(1) > 0
                fpr_unique = [0; fpr_unique];
                tpr_unique = [0; tpr_unique];
            elseif fpr_unique(1) == 0
                tpr_unique(1) = 0;
            end
            if fpr_unique(end) < 1
                fpr_unique = [fpr_unique; 1];
                tpr_unique = [tpr_unique; 1];
            elseif fpr_unique(end) == 1
                tpr_unique(end) = 1;
            end
            % Interpolate TPR at common FPR points
            if length(fpr_unique) >= 2
                interpTPR_Vector(si, :) = interp1(fpr_unique, tpr_unique, ...
                    commonFPR, 'linear');
            else
                interpTPR_Vector(si, :) = tpr_unique(1);
            end
            interpTPR_Vector(si, :) = max(0, min(1, interpTPR_Vector(si, :)));
        end
    end
    meanTPR_Vector = mean(interpTPR_Vector, 1, 'omitnan');
    stdTPR_Vector = std(interpTPR_Vector, 0, 1, 'omitnan');
    semTPR_Vector = stdTPR_Vector / sqrt(numValidSubjects);
    groupResults.ROC.Vector.meanTPR = meanTPR_Vector;
    groupResults.ROC.Vector.stdTPR = stdTPR_Vector;
    groupResults.ROC.Vector.semTPR = semTPR_Vector;
    groupResults.ROC.Vector.allTPR = interpTPR_Vector;
    groupResults.ROC.Vector.individualCurves = validROC_Vector;
    fprintf('  Vector mean AUC: %.3f ± %.3f\n', groupResults.Vector.AUC_mean, groupResults.Vector.AUC_std);
end
fprintf('\n');
if config.plotROC
    fprintf('Generating ROC curve plots...\n\n');
    timestamp = datestr(now, 'yyyymmdd_HHMMSS');
    if hasLSSM && hasVector
        fig1 = figure('Position', [100, 100, 1200, 500], 'Color', 'w');
        subplot(1, 2, 1);
        hold on;
        colors_lssm = parula(numValidSubjects);
        for si = 1:numValidSubjects
            if ~isempty(validROC_LSSM{si})
                plot(validROC_LSSM{si}.FPR, validROC_LSSM{si}.TPR, ...
                    'Color', [colors_lssm(si,:), 0.5], 'LineWidth', 1);
            end
        end
        plot([0 1], [0 1], 'k--', 'LineWidth', 1.5);  % Chance line
        plot(commonFPR, groupResults.ROC.LSSM.meanTPR, 'r-', 'LineWidth', 3);  % Mean ROC
        hold off;
        xlabel('False Positive Rate (1 - Specificity)', 'FontSize', 12);
        ylabel('True Positive Rate (Sensitivity)', 'FontSize', 12);
        title(sprintf('LSSM + LDA: Individual ROC Curves (n=%d)\nMean AUC = %.3f ± %.3f', ...
            numValidSubjects, groupResults.LSSM.AUC_mean, groupResults.LSSM.AUC_std), 'FontSize', 14);
        axis square;
        xlim([0 1]); ylim([0 1]);
        grid on;
        legend({'Individual subjects', '', '', '', '', 'Chance', 'Mean ROC'}, ...
            'Location', 'southeast');
        % Vector individual ROC curves
        subplot(1, 2, 2);
        hold on;
        colors_vec = parula(numValidSubjects);
        for si = 1:numValidSubjects
            if ~isempty(validROC_Vector{si})
                plot(validROC_Vector{si}.FPR, validROC_Vector{si}.TPR, ...
                    'Color', [colors_vec(si,:), 0.5], 'LineWidth', 1);
            end
        end
        plot([0 1], [0 1], 'k--', 'LineWidth', 1.5);
        plot(commonFPR, groupResults.ROC.Vector.meanTPR, 'b-', 'LineWidth', 3);
        hold off;
        xlabel('False Positive Rate (1 - Specificity)', 'FontSize', 12);
        ylabel('True Positive Rate (Sensitivity)', 'FontSize', 12);
        title(sprintf('Vector + LDA: Individual ROC Curves (n=%d)\nMean AUC = %.3f ± %.3f', ...
            numValidSubjects, groupResults.Vector.AUC_mean, groupResults.Vector.AUC_std), 'FontSize', 14);
        axis square;
        xlim([0 1]); ylim([0 1]);
        grid on;
        legend({'Individual subjects', '', '', '', '', 'Chance', 'Mean ROC'}, ...
            'Location', 'southeast');
        % Save figure
        saveas(fig1, fullfile(config.outputDir, sprintf('ROC_individual_%s.png', timestamp)));
        saveas(fig1, fullfile(config.outputDir, sprintf('ROC_individual_%s.fig', timestamp)));
        fprintf('  Saved: ROC_individual_%s.png\n', timestamp);
        fig2 = figure('Position', [100, 100, 700, 600], 'Color', 'w');
        hold on;
        % LSSM: shaded confidence band (±1 SEM)
        fill([commonFPR; flipud(commonFPR)], ...
            [groupResults.ROC.LSSM.meanTPR' + groupResults.ROC.LSSM.semTPR'; ...
             flipud(groupResults.ROC.LSSM.meanTPR' - groupResults.ROC.LSSM.semTPR')], ...
            [1 0.7 0.7], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
        % Vector: shaded confidence band (±1 SEM)
        fill([commonFPR; flipud(commonFPR)], ...
            [groupResults.ROC.Vector.meanTPR' + groupResults.ROC.Vector.semTPR'; ...
             flipud(groupResults.ROC.Vector.meanTPR' - groupResults.ROC.Vector.semTPR')], ...
            [0.7 0.7 1], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
        % Plot mean ROC curves
        h1 = plot(commonFPR, groupResults.ROC.LSSM.meanTPR, 'r-', 'LineWidth', 2.5);
        h2 = plot(commonFPR, groupResults.ROC.Vector.meanTPR, 'b-', 'LineWidth', 2.5);
        h3 = plot([0 1], [0 1], 'k--', 'LineWidth', 1.5);
        hold off;
        xlabel('False Positive Rate (1 - Specificity)', 'FontSize', 14);
        ylabel('True Positive Rate (Sensitivity)', 'FontSize', 14);
        title(sprintf('Mean ROC Curves (n=%d subjects)', numValidSubjects), 'FontSize', 16);
        legend([h1, h2, h3], ...
            {sprintf('LSSM + LDA (AUC = %.3f ± %.3f)', groupResults.LSSM.AUC_mean, groupResults.LSSM.AUC_std), ...
            sprintf('Vector + LDA (AUC = %.3f ± %.3f)', groupResults.Vector.AUC_mean, groupResults.Vector.AUC_std), ...
            'Chance'}, ...
            'Location', 'southeast', 'FontSize', 11);
        axis square;
        xlim([0 1]); ylim([0 1]);
        grid on;
        set(gca, 'FontSize', 12);
        % Save figure
        saveas(fig2, fullfile(config.outputDir, sprintf('ROC_mean_%s.png', timestamp)));
        saveas(fig2, fullfile(config.outputDir, sprintf('ROC_mean_%s.fig', timestamp)));
        fprintf('  Saved: ROC_mean_%s.png\n', timestamp);
        fig3 = figure('Position', [100, 100, 500, 500], 'Color', 'w');
        % Box plot
        boxData = [validAUC_LSSM; validAUC_Vector];
        groupLabels = [repmat({'LSSM'}, numValidSubjects, 1); repmat({'Vector'}, numValidSubjects, 1)];
        boxplot(boxData, groupLabels, 'Colors', 'rb', 'Widths', 0.5);
        hold on;
        % Add individual points with jitter
        jitterAmount = 0.1;
        x_lssm = ones(numValidSubjects, 1) + jitterAmount * (rand(numValidSubjects, 1) - 0.5);
        x_vec = 2 * ones(numValidSubjects, 1) + jitterAmount * (rand(numValidSubjects, 1) - 0.5);
        scatter(x_lssm, validAUC_LSSM, 40, 'r', 'filled', 'MarkerFaceAlpha', 0.5);
        scatter(x_vec, validAUC_Vector, 40, 'b', 'filled', 'MarkerFaceAlpha', 0.5);
        % Add chance line
        yline(0.5, 'k--', 'LineWidth', 1.5);
        hold off;
        ylabel('AUC', 'FontSize', 14);
        title(sprintf('AUC Distribution Comparison\np = %.4f (paired permutation)', ...
            groupResults.comparison.pValue), 'FontSize', 14);
        set(gca, 'FontSize', 12);
        ylim([0.3 1]);
        grid on;
        % Save figure
        saveas(fig3, fullfile(config.outputDir, sprintf('AUC_comparison_%s.png', timestamp)));
        saveas(fig3, fullfile(config.outputDir, sprintf('AUC_comparison_%s.fig', timestamp)));
        fprintf('  Saved: AUC_comparison_%s.png\n\n', timestamp);
    elseif hasVector
        fig1 = figure('Position', [100, 100, 600, 500], 'Color', 'w');
        hold on;
        colors_vec = parula(numValidSubjects);
        for si = 1:numValidSubjects
            if ~isempty(validROC_Vector{si})
                plot(validROC_Vector{si}.FPR, validROC_Vector{si}.TPR, ...
                    'Color', [colors_vec(si,:), 0.5], 'LineWidth', 1);
            end
        end
        plot([0 1], [0 1], 'k--', 'LineWidth', 1.5);
        plot(commonFPR, groupResults.ROC.Vector.meanTPR, 'b-', 'LineWidth', 3);
        hold off;
        xlabel('False Positive Rate (1 - Specificity)', 'FontSize', 12);
        ylabel('True Positive Rate (Sensitivity)', 'FontSize', 12);
        title(sprintf('Vector + LDA: Individual ROC Curves (n=%d)\nMean AUC = %.3f ± %.3f', ...
            numValidSubjects, groupResults.Vector.AUC_mean, groupResults.Vector.AUC_std), 'FontSize', 14);
        axis square;
        xlim([0 1]); ylim([0 1]);
        grid on;
        legend({'Individual subjects', '', '', '', '', 'Chance', 'Mean ROC'}, ...
            'Location', 'southeast');
        saveas(fig1, fullfile(config.outputDir, sprintf('ROC_vector_individual_%s.png', timestamp)));
        saveas(fig1, fullfile(config.outputDir, sprintf('ROC_vector_individual_%s.fig', timestamp)));
        fprintf('  Saved: ROC_vector_individual_%s.png\n', timestamp);
        fig2 = figure('Position', [100, 100, 600, 500], 'Color', 'w');
        hold on;
        fill([commonFPR; flipud(commonFPR)], ...
            [groupResults.ROC.Vector.meanTPR' + groupResults.ROC.Vector.semTPR'; ...
             flipud(groupResults.ROC.Vector.meanTPR' - groupResults.ROC.Vector.semTPR')], ...
            [0.7 0.7 1], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
        h1 = plot(commonFPR, groupResults.ROC.Vector.meanTPR, 'b-', 'LineWidth', 2.5);
        h2 = plot([0 1], [0 1], 'k--', 'LineWidth', 1.5);
        hold off;
        xlabel('False Positive Rate (1 - Specificity)', 'FontSize', 14);
        ylabel('True Positive Rate (Sensitivity)', 'FontSize', 14);
        title(sprintf('Mean ROC Curve (Vector + LDA, n=%d subjects)', numValidSubjects), 'FontSize', 16);
        legend([h1, h2], ...
            {sprintf('Vector + LDA (AUC = %.3f ± %.3f)', groupResults.Vector.AUC_mean, groupResults.Vector.AUC_std), ...
            'Chance'}, ...
            'Location', 'southeast', 'FontSize', 11);
        axis square;
        xlim([0 1]); ylim([0 1]);
        grid on;
        set(gca, 'FontSize', 12);
        saveas(fig2, fullfile(config.outputDir, sprintf('ROC_vector_mean_%s.png', timestamp)));
        saveas(fig2, fullfile(config.outputDir, sprintf('ROC_vector_mean_%s.fig', timestamp)));
        fprintf('  Saved: ROC_vector_mean_%s.png\n', timestamp);
        fig3 = figure('Position', [100, 100, 500, 500], 'Color', 'w');
        boxplot(validAUC_Vector, 'Colors', 'b', 'Widths', 0.5);
        hold on;
        jitterAmount = 0.1;
        x_vec = ones(numValidSubjects, 1) + jitterAmount * (rand(numValidSubjects, 1) - 0.5);
        scatter(x_vec, validAUC_Vector, 40, 'b', 'filled', 'MarkerFaceAlpha', 0.5);
        yline(0.5, 'k--', 'LineWidth', 1.5);
        hold off;
        ylabel('AUC', 'FontSize', 14);
        title('Vector AUC Distribution', 'FontSize', 14);
        set(gca, 'XTickLabel', {'Vector'});
        set(gca, 'FontSize', 12);
        ylim([0.3 1]);
        grid on;
        saveas(fig3, fullfile(config.outputDir, sprintf('AUC_vector_%s.png', timestamp)));
        saveas(fig3, fullfile(config.outputDir, sprintf('AUC_vector_%s.fig', timestamp)));
        fprintf('  Saved: AUC_vector_%s.png\n\n', timestamp);
    end
end
fprintf('=============================================================\n');
fprintf('   FEATURE IMPORTANCE ANALYSIS (with FDR correction)\n');
fprintf('=============================================================\n\n');
validFeatureWeights_Vector = allFeatureWeightsNorm_Vector(validIdx);
numFeatPerSubj = cellfun(@length, validFeatureWeights_Vector);
if ~isempty(numFeatPerSubj) && all(numFeatPerSubj == numFeatPerSubj(1))
    numFeatures_Vector = numFeatPerSubj(1);
    featureWeightMatrix = cell2mat(validFeatureWeights_Vector(:));
    groupResults.Vector.featureWeights.mean = mean(featureWeightMatrix, 1, 'omitnan');
    groupResults.Vector.featureWeights.std = std(featureWeightMatrix, 0, 1, 'omitnan');
    groupResults.Vector.featureWeights.numFeatures = numFeatures_Vector;
    fprintf('Testing %d Vector features (%d permutations each)...\n', ...
        numFeatures_Vector, config.featurePermutations);
    pValues_Vector = zeros(1, numFeatures_Vector);
    for fi = 1:numFeatures_Vector
        % --- formerly featurePermutationTest (two-tailed sign-flip test of mean weight ~= 0) ---
        fpData = featureWeightMatrix(:, fi);
        fpData = fpData(~isnan(fpData));
        if isempty(fpData)
            pValues_Vector(fi) = 1;     % feature never drawn in any subject: not testable
            continue;
        end
        fpN = length(fpData);
        fpAbsObserved = abs(mean(fpData));
        fpExceed = 0;
        for permi = 1:config.featurePermutations
            fpSigns = 2 * (rand(fpN, 1) > 0.5) - 1;
            fpPermMean = mean(fpSigns .* fpData);
            if abs(fpPermMean) >= fpAbsObserved
                fpExceed = fpExceed + 1;
            end
        end
        pValues_Vector(fi) = (fpExceed + 1) / (config.featurePermutations + 1);
    end
    groupResults.Vector.featureWeights.pValues = pValues_Vector;
    groupResults.Vector.featureWeights.significant_uncorrected = pValues_Vector < config.alphaLevel;
    if config.applyFDR
        % --- formerly benjaminiHochberg(pValues_Vector, config.alphaLevel) ---
        bhP = pValues_Vector(:);
        bhM = length(bhP);
        if bhM <= 1
            pValues_FDR = bhP;
        else
            [bhSortedP, bhSortIdx] = sort(bhP);
            bhRanks = (1:bhM)';
            bhAdjSorted = bhSortedP .* bhM ./ bhRanks;
            for bhi = bhM-1:-1:1
                bhAdjSorted(bhi) = min(bhAdjSorted(bhi), bhAdjSorted(bhi+1));
            end
            bhAdjSorted = min(bhAdjSorted, 1);
            [~, bhOrigIdx] = sort(bhSortIdx);
            pValues_FDR = bhAdjSorted(bhOrigIdx);
        end
        significant_FDR = pValues_FDR < config.alphaLevel;
        groupResults.Vector.featureWeights.pValues_FDR = pValues_FDR;
        groupResults.Vector.featureWeights.significant_FDR = significant_FDR;
        groupResults.Vector.featureWeights.significant = significant_FDR;
        fprintf('  Significant (uncorrected): %d/%d\n', ...
            sum(groupResults.Vector.featureWeights.significant_uncorrected), numFeatures_Vector);
        fprintf('  Significant (FDR): %d/%d\n\n', sum(significant_FDR), numFeatures_Vector);
    else
        groupResults.Vector.featureWeights.significant = groupResults.Vector.featureWeights.significant_uncorrected;
    end
else
    warning('Vector feature dimensions vary. Skipping group feature analysis.');
    groupResults.Vector.featureWeights = [];
end
% --- LSSM Feature Weights ---
validFeatureWeights_LSSM = allFeatureWeightsNorm_LSSM(validIdx);
numFeatPerSubj_LSSM = cellfun(@length, validFeatureWeights_LSSM);
if ~isempty(numFeatPerSubj_LSSM) && all(numFeatPerSubj_LSSM == numFeatPerSubj_LSSM(1))
    numFeatures_LSSM = numFeatPerSubj_LSSM(1);
    featureWeightMatrix_LSSM = cell2mat(validFeatureWeights_LSSM(:));
    groupResults.LSSM.featureWeights.mean = mean(featureWeightMatrix_LSSM, 1);
    groupResults.LSSM.featureWeights.std = std(featureWeightMatrix_LSSM, 0, 1);
    groupResults.LSSM.featureWeights.numFeatures = numFeatures_LSSM;
    fprintf('Testing %d LSSM features...\n', numFeatures_LSSM);
    pValues_LSSM = zeros(1, numFeatures_LSSM);
    for fi = 1:numFeatures_LSSM
        % --- formerly featurePermutationTest (two-tailed sign-flip test of mean weight ~= 0) ---
        fpData = featureWeightMatrix_LSSM(:, fi);
        fpN = length(fpData);
        fpAbsObserved = abs(mean(fpData));
        fpExceed = 0;
        for permi = 1:config.featurePermutations
            fpSigns = 2 * (rand(fpN, 1) > 0.5) - 1;
            fpPermMean = mean(fpSigns .* fpData);
            if abs(fpPermMean) >= fpAbsObserved
                fpExceed = fpExceed + 1;
            end
        end
        pValues_LSSM(fi) = (fpExceed + 1) / (config.featurePermutations + 1);
    end
    groupResults.LSSM.featureWeights.pValues = pValues_LSSM;
    if config.applyFDR
        % --- formerly benjaminiHochberg(pValues_LSSM, config.alphaLevel) ---
        bhP = pValues_LSSM(:);
        bhM = length(bhP);
        if bhM <= 1
            pValues_FDR_LSSM = bhP;
        else
            [bhSortedP, bhSortIdx] = sort(bhP);
            bhRanks = (1:bhM)';
            bhAdjSorted = bhSortedP .* bhM ./ bhRanks;
            for bhi = bhM-1:-1:1
                bhAdjSorted(bhi) = min(bhAdjSorted(bhi), bhAdjSorted(bhi+1));
            end
            bhAdjSorted = min(bhAdjSorted, 1);
            [~, bhOrigIdx] = sort(bhSortIdx);
            pValues_FDR_LSSM = bhAdjSorted(bhOrigIdx);
        end
        significant_FDR_LSSM = pValues_FDR_LSSM < config.alphaLevel;
        groupResults.LSSM.featureWeights.pValues_FDR = pValues_FDR_LSSM;
        groupResults.LSSM.featureWeights.significant_FDR = significant_FDR_LSSM;
        groupResults.LSSM.featureWeights.significant = significant_FDR_LSSM;
        fprintf('  Significant (FDR): %d/%d\n\n', sum(significant_FDR_LSSM), numFeatures_LSSM);
    end
else
    fprintf('LSSM latent dimensions vary: ');
    fprintf('%d ', allLatentDim_LSSM(validIdx));
    fprintf('\n\n');
    groupResults.LSSM.featureWeights.note = 'Dimensions vary across subjects';
end
fprintf('=============================================================\n');
fprintf('   SAVING RESULTS\n');
fprintf('=============================================================\n\n');
% Store individual results
groupResults.individual.AUC_LSSM = allAUC_LSSM;
groupResults.individual.AUC_Vector = allAUC_Vector;
groupResults.individual.Accuracy_LSSM = allAcc_LSSM;
groupResults.individual.Accuracy_Vector = allAcc_Vector;
groupResults.individual.pValue_LSSM = allPval_LSSM;
groupResults.individual.pValue_Vector = allPval_Vector;
groupResults.individual.LatentDim_LSSM = allLatentDim_LSSM;
groupResults.individual.validSubjects = validSubjects;
% Random feature-subset results
groupResults.individual.numFeatures = allNumFeatures;          % total features per subject
groupResults.individual.drawFeatIdx = allDrawFeat;             % each cell: [timeDraw x nFeatSub] feature indices drawn
groupResults.individual.drawAUC_LSSM = allDrawAUC_LSSM;        % [subjects x timeDraw] AUC of every draw
groupResults.individual.drawAUC_Vector = allDrawAUC_Vector;
groupResults.individual.fastCheckMaxDiff = allFastCheck;        
timestamp = datestr(now, 'yyyymmdd_HHMMSS');
% Save MAT file (includes all ROC data)
matFilename = fullfile(config.outputDir, sprintf('groupResults_%s.mat', timestamp));
save(matFilename, 'groupResults', '-v7.3');
fprintf('Saved: %s\n', matFilename);
% Save summary CSV
if hasLSSM && hasVector
    summaryTable = table(...
        {'LSSM'; 'Vector'}, ...
        [groupResults.LSSM.AUC_mean; groupResults.Vector.AUC_mean], ...
        [groupResults.LSSM.AUC_std; groupResults.Vector.AUC_std], ...
        [groupResults.LSSM.permutation.pValue; groupResults.Vector.permutation.pValue], ...
        [groupResults.LSSM.Accuracy_mean; groupResults.Vector.Accuracy_mean], ...
        'VariableNames', {'Method', 'AUC_Mean', 'AUC_Std', 'pValue', 'Accuracy'});
elseif hasVector
    summaryTable = table(...
        {'Vector'}, ...
        groupResults.Vector.AUC_mean, ...
        groupResults.Vector.AUC_std, ...
        groupResults.Vector.permutation.pValue, ...
        groupResults.Vector.Accuracy_mean, ...
        'VariableNames', {'Method', 'AUC_Mean', 'AUC_Std', 'pValue', 'Accuracy'});
else
    summaryTable = table();
end
csvFilename = fullfile(config.outputDir, sprintf('groupSummary_%s.csv', timestamp));
writetable(summaryTable, csvFilename);
fprintf('Saved: %s\n', csvFilename);
% Save individual results CSV
if hasLSSM && hasVector
    indivTable = table(...
        find(validIdx), validAUC_LSSM, validAUC_Vector, ...
        allAcc_LSSM(validIdx), allAcc_Vector(validIdx), ...
        allPval_LSSM(validIdx), allPval_Vector(validIdx), ...
        'VariableNames', {'SubjectID', 'AUC_LSSM', 'AUC_Vector', 'Acc_LSSM', 'Acc_Vector', 'pVal_LSSM', 'pVal_Vector'});
elseif hasVector
    indivTable = table(...
        find(validIdx), validAUC_Vector, allAcc_Vector(validIdx), allPval_Vector(validIdx), ...
        'VariableNames', {'SubjectID', 'AUC_Vector', 'Acc_Vector', 'pVal_Vector'});
else
    indivTable = table();
end
indivFilename = fullfile(config.outputDir, sprintf('individualResults_%s.csv', timestamp));
writetable(indivTable, indivFilename);
fprintf('Saved: %s\n', indivFilename);
% Save ROC curve data as CSV (mean curves)
if hasLSSM && hasVector
    rocTable = table(commonFPR, meanTPR_LSSM', stdTPR_LSSM', meanTPR_Vector', stdTPR_Vector', ...
        'VariableNames', {'FPR', 'TPR_LSSM_mean', 'TPR_LSSM_std', 'TPR_Vector_mean', 'TPR_Vector_std'});
elseif hasVector
    rocTable = table(commonFPR, meanTPR_Vector', stdTPR_Vector', ...
        'VariableNames', {'FPR', 'TPR_Vector_mean', 'TPR_Vector_std'});
else
    rocTable = table();
end
rocFilename = fullfile(config.outputDir, sprintf('ROC_data_%s.csv', timestamp));
writetable(rocTable, rocFilename);
fprintf('Saved: %s\n', rocFilename);
fprintf('\n=============================================================\n');
fprintf('   FINAL SUMMARY\n');
fprintf('=============================================================\n\n');
if hasLSSM
    fprintf('LSSM + LDA:   AUC = %.3f ± %.3f, p = %.6f\n', ...
        groupResults.LSSM.AUC_mean, groupResults.LSSM.AUC_std, groupResults.LSSM.permutation.pValue);
end
if hasVector
    fprintf('Vector + LDA: AUC = %.3f ± %.3f, p = %.6f\n', ...
        groupResults.Vector.AUC_mean, groupResults.Vector.AUC_std, groupResults.Vector.permutation.pValue);
end
if hasLSSM && hasVector && ~isempty(aucDiff)
    fprintf('Comparison:   diff = %.4f, p = %.6f\n\n', mean(aucDiff), groupResults.comparison.pValue);
end
fprintf('Feature subsets: n = %d features, %d draws per subject\n', config.nFeatSub, config.timeDraw);
fprintf('Total analysis time: %.1f min\n', totalTime/60);
fprintf('Results saved to: %s\n\n', config.outputDir);