% [1] - Initialize MVPAlab toolbox:
cfg = mvpalab_init();

% [2] - Run the configuration file:
run cfg_file.m

% [3] – Import data and extract feature vectors:
[cfg,data,fv] = mvpalab_import(cfg);

% [4] – Compute a multivariate analysis:
[result,cfg] = mvpalab_mvpa(cfg,fv);
%mvpalab_mvcc(cfg,fv);
%mvpalab_sfilter(cfg,fv)

% Compute permutation test:
[permaps,cfg] = mvpalab_permaps(cfg,fv);
stats = mvpalab_permtest(cfg,result,permaps);

% [5] – Plot the results:
run plot_file.m

close all
clear
delete(gcp('nocreate'));
myCluster = parcluster('local');
delete(myCluster.Jobs);