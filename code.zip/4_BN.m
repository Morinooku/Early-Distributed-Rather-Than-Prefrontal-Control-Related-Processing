rootDir   = '';    
savePath  = '';
eeglabPath = ''; 
fs        = 1000;    
bands     = []; 
doFilter  = true; 
filtOrder = [];
trialMode = 'trial-kept';
sparsity  = 0.20;    
nSurrogate = 20;    
nWorkers   = 12; 
nSubBand    = 4;
maskBand    = true;
swapFactor  = 5;     % edge-swap attempts per edge in surrogate randomization
rngSeed     = 42;   
saveResults = true;  
outMatFile  = 'brain_network_results_tk.mat';  
if isempty(rootDir)
    error(['rootDir is empty. Please set rootDir to the folder that ' ...
           'contains the data .mat files (at any depth), then re-run.']);
end
if exist(rootDir,'dir') ~= 7
    error('rootDir does not exist or is not a folder:\n  %s', rootDir);
end
if ~isnumeric(bands) || isempty(bands) || size(bands, 2) ~= 2
    error(['bands must be a numeric nBand x 2 matrix: one [lower upper] ' ...
           'row per pass-band, e.g. [1 4] or [32 45; 55 60].']);
end
if any(~isfinite(bands(:))) || any(bands(:) <= 0)
    error('bands must contain finite positive frequencies.');
end
badRow = find(bands(:,2) <= bands(:,1), 1);
if ~isempty(badRow)
    error('band %d is empty: its upper edge (%g Hz) is not above its lower edge (%g Hz).', ...
          badRow, bands(badRow,2), bands(badRow,1));
end
bands = sortrows(bands, 1);          % rows in ascending frequency order
nBand = size(bands, 1);              % # of pass-bands
ovl   = find(bands(2:end,1) <= bands(1:end-1,2), 1);
if ~isempty(ovl)
    error(['the pass-bands must be disjoint (a real gap between them): ' ...
           'band %d ends at %g Hz but band %d starts at %g Hz.'], ...
          ovl, bands(ovl,2), ovl+1, bands(ovl+1,1));
end
if nBand > 1 && ~maskBand
    warning(['bands has %d rows, so maskBand is forced to true: with an ' ...
             'unmasked Hilbert transform the excluded gap(s) would come ' ...
             'back into the analytic signal (only attenuated by the FIR ' ...
             'stopbands), which is exactly what splitting the band avoids.'], nBand);
    maskBand = true;
end
if nWorkers < 0 || nWorkers ~= round(nWorkers)
    error('nWorkers must be a non-negative integer (0 = serial).');
end
if ~(ischar(trialMode) || isstring(trialMode))
    error('trialMode must be the text ''averaged'' or ''trial-kept''.');
end
trialMode = lower(strtrim(char(trialMode)));
switch trialMode
    case 'averaged'
        keepTrials = false;
    case {'trial-kept', 'trial_kept', 'trialkept'}
        trialMode  = 'trial-kept';
        keepTrials = true;
    otherwise
        error(['trialMode must be ''averaged'' (metrics averaged over the ' ...
               'processed trials) or ''trial-kept'' (every trial kept, ' ...
               'nothing averaged), not ''%s''.'], trialMode);
end
if keepTrials
    fprintf(['Trial mode: TRIAL-KEPT -- no averaging; every field gets a ' ...
             'trailing trial dimension (nTrials columns).\n']);
else
    fprintf(['Trial mode: AVERAGED -- every metric is averaged over the ' ...
             'processed trials.\n']);
end
ordPred = NaN(1, nBand);            % predicted FIR order per band (NaN if not filtering)
ordReq  = cell(1, nBand);           % order REQUESTED per band ([] = EEGLAB default)
if doFilter
    if isempty(which('pop_eegfiltnew')) && ~isempty(eeglabPath)
        if exist(eeglabPath, 'dir') ~= 7
            error('eeglabPath does not exist or is not a folder:\n  %s', eeglabPath);
        end
        addpath(eeglabPath);        % the EEGLAB root folder only ...
        eeglab nogui;               % ... this adds all its sub-folders (no GUI)
    end
    if isempty(which('pop_eegfiltnew')) || isempty(which('eeg_emptyset'))
        error(['EEGLAB was not found on the MATLAB path (pop_eegfiltnew / ' ...
               'eeg_emptyset missing). Set eeglabPath to your EEGLAB root ' ...
               'folder, or run eeglab once before this script -- or set ' ...
               'doFilter = false if your data are already band-pass filtered.']);
    end
    % --- every band must fit under Nyquist ---
    if any(bands(:,2) >= fs/2)
        error(['every upper band edge must be below Nyquist (%g Hz) to be ' ...
               'band-pass filtered (highest edge given: %g Hz).'], ...
              fs/2, max(bands(:,2)));
    end
    if isempty(filtOrder)
        ordReq(:) = {[]};
    elseif isscalar(filtOrder)
        if filtOrder <= 0 || mod(filtOrder, 2) ~= 0
            error('filtOrder must be an even positive integer (or [] for the default).');
        end
        ordReq(:) = {filtOrder};
    elseif numel(filtOrder) == nBand
        if any(filtOrder <= 0) || any(mod(filtOrder, 2) ~= 0)
            error('every entry of filtOrder must be an even positive integer.');
        end
        for bi = 1:nBand
            ordReq{bi} = filtOrder(bi);
        end
    else
        error(['filtOrder must be [], a single even order used for all ' ...
               'bands, or a vector with one even order per band (%d rows ' ...
               'in "bands").'], nBand);
    end
    for bi = 1:nBand
        if isempty(ordReq{bi})
            maxDf       = min(bands(bi,1), fs/2 - bands(bi,2));   % widest transition band that fits
            df          = min(max(bands(bi,1) * 0.25, 2), maxDf); % Hz
            ordPred(bi) = ceil((3.3 / (df / fs)) / 2) * 2;        % even
        else
            ordPred(bi) = ordReq{bi};
        end
    end
    fprintf(['Band-pass filtering ON: %d pass-band(s), EEGLAB ' ...
             'pop_eegfiltnew (zero-phase Hamming-windowed sinc FIR).\n'], nBand);
    for bi = 1:nBand
        fprintf('  band %d: %g-%g Hz, filter order %d samples (%.3f s).\n', ...
                bi, bands(bi,1), bands(bi,2), ordPred(bi), ordPred(bi) / fs);
    end
    fprintf(['  -> only epochs LONGER than %d samples (the longest of these ' ...
             'filters) can be filtered.\n'], max(ordPred));
    if nBand > 1
        fprintf(['  the %d pass-bands are filtered separately and SUMMED ' ...
                 '-> one signal over their union.\n'], nBand);
    end
else
    fprintf(['Band-pass filtering OFF (doFilter = false): data are assumed ' ...
             'to be filtered already to']);
    fprintf(' %g-%g Hz', bands.');
    fprintf('.\n');
end
if nWorkers > 0
    if isempty(ver('parallel'))
        warning('Parallel Computing Toolbox not found -- running serially (nWorkers = 0).');
        nWorkers = 0;
    else
        nMaxW = parcluster().NumWorkers;      % what the default profile allows
        if nWorkers > nMaxW
            warning('nWorkers = %d exceeds the %d workers available -- using %d.', ...
                    nWorkers, nMaxW, nMaxW);
            nWorkers = nMaxW;
        end
        pool = gcp('nocreate');
        if isempty(pool) || pool.NumWorkers < nWorkers
            if ~isempty(pool), delete(pool); end
            pool = parpool(nWorkers);
        end
        fprintf('Parallel pool open: using %d of %d worker(s).\n', nWorkers, pool.NumWorkers);
    end
end
measureNames = {'Pearson','MSC','iCoh','PSI','PLV','PLI','wPLI'};
metricScalars = {'Cp','gamma','Lp','lambda','sigma','Eg','Eloc'};
metricVectors = {'Ncp','Ne','Nle','Ndc','Nbc'};
nMeasure = numel(measureNames);
fl = dir(fullfile(rootDir, '**', '*.mat'));
fl = fl(~[fl.isdir]);                                  % files only
fl = fl(~strcmpi({fl.name}, outMatFile));              % drop previous results files
if isempty(fl)
    error('No data .mat files found in or below:\n  %s', rootDir);
end
dataFolders = unique({fl.folder});                     % sorted, one entry per folder
dataFiles   = cell(0, 1);                              % full path of each data file
for k = 1:numel(dataFolders)
    inThis = fl(strcmp({fl.folder}, dataFolders{k}));
    if numel(inThis) > 1
        warning('Folder holds %d .mat files (expected exactly 1) -- skipped:\n  %s\n  (%s)', ...
                numel(inThis), dataFolders{k}, strjoin({inThis.name}, ', '));
        continue;
    end
    dataFiles{end+1, 1} = fullfile(inThis.folder, inThis.name); %#ok<AGROW>
end
nFiles = numel(dataFiles);
if nFiles == 0
    error('Every folder with .mat files holds more than one -- nothing to analyse.');
end
tmp  = dir(rootDir);
kDot = find(strcmp({tmp.name}, '.'), 1);
if isempty(kDot), rootAbs = rootDir; else, rootAbs = tmp(kDot).folder; end
relFolders = cell(nFiles, 1);
for k = 1:nFiles
    rf = fileparts(dataFiles{k});
    if strncmp(rf, rootAbs, numel(rootAbs)), rf = rf(numel(rootAbs)+1:end); end
    rf = regexprep(rf, '^[\\/]+', '');                 % drop the leading separator
    if isempty(rf), rf = '.'; end
    relFolders{k} = rf;
end

fprintf('Found %d data file(s) (one per folder) in or below:\n  %s\n', nFiles, rootDir);
outFolders = cell(nFiles, 1);
saveAbs    = '';                                   % absolute savePath ('' = not used)
if saveResults && ~isempty(savePath)
    if exist(savePath, 'dir') ~= 7
        [okMk, msgMk] = mkdir(savePath);
        if ~okMk
            error('Could not create savePath:\n  %s\n  (%s)', savePath, msgMk);
        end
        fprintf('Created savePath: %s\n', savePath);
    end
    tmpS  = dir(savePath);
    kDotS = find(strcmp({tmpS.name}, '.'), 1);
    if isempty(kDotS), saveAbs = savePath; else, saveAbs = tmpS(kDotS).folder; end
    if strncmpi([saveAbs filesep], [rootAbs filesep], numel(rootAbs) + 1)
        warning(['savePath lies inside rootDir -- the result files will sit ' ...
                 'among your data. Re-runs still ignore them (they are ' ...
                 'filtered out by the name in outMatFile), but a folder ' ...
                 'holding a data file AND another .mat would be skipped.']);
    end
    for k = 1:nFiles
        if strcmp(relFolders{k}, '.')
            outFolders{k} = saveAbs;               % data file sits directly in rootDir
        else
            outFolders{k} = fullfile(saveAbs, relFolders{k});
        end
        if exist(outFolders{k}, 'dir') ~= 7
            [okMk, msgMk] = mkdir(outFolders{k});
            if ~okMk
                error('Could not create the result folder:\n  %s\n  (%s)', ...
                      outFolders{k}, msgMk);
            end
        end
    end
    fprintf(['Results go to (folder tree of rootDir mirrored, missing ' ...
             'folders created):\n  %s\n'], saveAbs);
else
    for k = 1:nFiles
        outFolders{k} = fileparts(dataFiles{k});   % next to the data file
    end
    if saveResults
        fprintf('Results go next to each data file (savePath is empty).\n');
    else
        fprintf('saveResults = false: nothing is written to disk.\n');
    end
end
allResults = cell(nFiles, 1);
fileStatus = repmat({'skipped'}, nFiles, 1);
meta = struct();
meta.rootDir        = rootDir;
meta.savePath       = savePath;          % result root from the header ('' = next to the data)
meta.dataFile       = '';                % full path of the analysed .mat (set per file)
meta.relFolder      = '';                % its folder relative to rootDir (set per file)
meta.fs             = fs;
meta.band           = bands;             % nBand x 2, one [lower upper] row per pass-band
meta.nBand          = nBand;             % 1 = plain band-pass, >1 = union of disjoint bands
meta.maskBand       = maskBand;          % FFT bins outside the band(s) zeroed for the Hilbert signal?
meta.filtered       = doFilter;          % was the band-pass applied by this script?
if doFilter
    meta.filtFunc   = ['EEGLAB pop_eegfiltnew: one-pass Hamming-windowed sinc ' ...
                       'FIR, group-delay compensated (zero phase), each epoch ' ...
                       'filtered as its own segment'];
else
    meta.filtFunc   = 'none (data assumed band-pass filtered before this script)';
end
meta.filtOrderReq   = filtOrder;         % what you asked for ([] = EEGLAB default)
meta.filtOrder      = NaN(1, nBand);     % order actually used per band (set per file below)
meta.sparsity       = sparsity;
meta.nSurrogate     = nSurrogate;
meta.nSubBand       = nSubBand;          % PSI sub-bands PER pass-band
meta.connMethod     = ['Hilbert analytic signal, single-trial (MSC/iCoh over the ' ...
                       'whole analysis band; PSI across adjacent sub-bands within ' ...
                       'a pass-band)'];
meta.swapFactor     = swapFactor;
meta.rngSeed        = rngSeed;
meta.nWorkers       = nWorkers;          % parallel workers used for the trial loop (0 = serial)
meta.trialMode      = trialMode;         % 'averaged' or 'trial-kept' (see TRIAL HANDLING)
meta.measureNames   = measureNames;
meta.scalarMetrics  = metricScalars;
meta.vectorMetrics  = metricVectors;
meta.networkType    = 'binary, sparsity-thresholded, undirected';
meta.nodalCentrality = ['Ndc = raw degree (# edges per node, not normalized); ' ...
                        'Nbc = raw betweenness (Freeman: each unordered pair counted once, ' ...
                        'not normalized; = BCT betweenness_bin / 2)'];
meta.nanHandling    = ['assessed after band-pass filtering; ' ...
                       'all-NaN channels never processed (positions kept as NaN); ' ...
                       'per trial, channels with any NaN/Inf dropped from that trial; ' ...
                       'trials with < 3 usable channels skipped'];
meta.created        = '';                % time stamp (set per file)
warnedSub  = false;  % gate the "too few PSI sub-bands" warning to print once
warnedBins = false;  % gate the "no FFT bin inside the band(s)" warning likewise
for k = 1:nFiles
    thisFile   = dataFiles{k};                         % full path of the data .mat
    thisFolder = fileparts(thisFile);                  % the folder the data file sits in
    [~, thisName] = fileparts(thisFile);               % file name without .mat (for messages)
    fprintf('\n=== File %d/%d: %s ===\n', k, nFiles, relFolders{k});
    S0 = load(thisFile);
    if ~isfield(S0, 'data')
        warning('File %s has no variable "data" -- skipped.', thisFile);
        fileStatus{k} = 'skipped: no variable "data"';
        continue;
    end
    data = double(S0.data);
    nCh     = size(data, 1);
    nT      = size(data, 2);
    nTrials = size(data, 3);
    if nCh < 3 || nT < 4
        warning('File %s: data too small (%dx%dx%d) -- skipped.', ...
                thisFile, nCh, nT, nTrials);
        fileStatus{k} = 'skipped: data too small';
        continue;
    end
    if isfield(S0, 'decodeScore')
        decodeScore = S0.decodeScore;
    else
        decodeScore = [];
        warning('File %s has no variable "decodeScore" -- saved as [].', thisFile);
    end
    if isfield(S0, 'runID')
        runID = S0.runID;
    else
        runID = [];
        warning('File %s has no variable "runID" -- saved as [].', thisFile);
    end
    if ~isempty(decodeScore) && numel(decodeScore) ~= nTrials
        warning('File %s: decodeScore has %d entries but data has %d trials.', ...
                thisFile, numel(decodeScore), nTrials);
    end
    if ~isempty(runID) && numel(runID) ~= nTrials
        warning('File %s: runID has %d entries but data has %d trials.', ...
                thisFile, numel(runID), nTrials);
    end
    if doFilter
        dataF    = zeros(size(data));       % accumulates the pass-bands
        ordUsed  = NaN(1, nBand);           % order really applied, per band
        skipFile = false;
        nOutFilt = nargout('pop_eegfiltnew');    % < 0 means varargout
        for bi = 1:nBand
            EEGf         = eeg_emptyset();      % all fields EEGLAB expects
            EEGf.setname = thisName;
            EEGf.data    = data;                % nCh x nT x nTrials (double), UNfiltered
            EEGf.srate   = fs;
            EEGf.nbchan  = nCh;
            EEGf.pnts    = nT;
            EEGf.trials  = nTrials;
            EEGf.xmin    = 0;                   % epoch time axis is irrelevant here,
            EEGf.xmax    = (nT - 1) / fs;       % but must be consistent with pnts/srate
            EEGf.event   = [];                  % no boundary events
            if nOutFilt < 0 || nOutFilt >= 3
                [EEGf, ~, bFIR] = pop_eegfiltnew(EEGf, bands(bi,1), bands(bi,2), ordReq{bi});
                ordUsed(bi) = numel(bFIR) - 1;
            else
                EEGf        = pop_eegfiltnew(EEGf, bands(bi,1), bands(bi,2), ordReq{bi});
                ordUsed(bi) = ordPred(bi);
            end
            if nT <= ordUsed(bi)
                warning(['File %s: epochs are %d samples but the FIR order for ' ...
                         'band %d (%g-%g Hz) is %d, so pop_eegfiltnew cannot ' ...
                         'filter them (EEGLAB skips segments shorter than the ' ...
                         'filter) -- file skipped. Use an even filtOrder < %d, ' ...
                         'or filter the continuous data before epoching and set ' ...
                         'doFilter = false.'], ...
                         thisFile, nT, bi, bands(bi,1), bands(bi,2), ordUsed(bi), nT);
                fileStatus{k} = sprintf(['skipped: epoch (%d) shorter than filter ' ...
                                         'order (%d, band %d)'], nT, ordUsed(bi), bi);
                skipFile = true;
                break;
            end
            dataF = dataF + double(EEGf.data);  % linear superposition of the pass-bands
            EEGf  = [];                    % drop the copy (data arrays can be large)
        end
        if skipFile
            continue;                      % on to the next data file
        end
        data  = dataF;                     % filtered, same nCh x nT x nTrials layout
        dataF = [];                        % drop the accumulator
        meta.filtOrder = ordUsed;          % stored next to this file's results
        for bi = 1:nBand
            fprintf('  band-pass %g-%g Hz applied (FIR order %d, %.3f s).\n', ...
                    bands(bi,1), bands(bi,2), ordUsed(bi), ordUsed(bi) / fs);
        end
    end
    chanDead = all(all(~isfinite(data), 2), 3);   % nCh x 1 logical
    nDead    = sum(chanDead);
    if nCh - nDead < 3
        warning('File %s: only %d of %d channels contain data -- skipped.', ...
                thisFile, nCh - nDead, nCh);
        fileStatus{k} = 'skipped: < 3 channels contain data';
        continue;
    end

    fprintf('  %-28s  ch=%d (%d all-NaN)  time=%d  trials=%d\n', ...
            thisName, nCh, nDead, nT, nTrials);
    if mod(nT, 2) == 0
        hvec(1) = 1; hvec(nT/2 + 1) = 1; hvec(2:nT/2) = 2;
    else
        hvec(1) = 1; hvec(2:(nT+1)/2) = 2;
    end
    inAny = false(1, nT);               % bins inside ANY pass-band
    nBinB = zeros(1, nBand);            % in-band bins, per pass-band
    for bi = 1:nBand
        inB      = (freqB >= bands(bi,1)) & (freqB <= bands(bi,2)) & (freqB <= fs/2);
        inAny    = inAny | inB;
        nBinB(bi) = sum(inB);
    end
    if maskBand
        hvec(~inAny) = 0;
    end
    if ~warnedBins && ~any(inAny)
        warning(['No FFT bin falls inside the analysis band(s) for %s: with ' ...
            'nT = %d samples at fs = %g Hz the bin spacing is %g Hz, which is ' ...
            'coarser than the band(s). The analytic signal is empty and all ' ...
            'Hilbert-based measures are degenerate -- use longer epochs or ' ...
            'wider bands. (Shown once.)'], thisFile, nT, fs, fs / nT);
        warnedBins = true;
    end
    nSubB = min(nSubBand, max(1, nBinB));       % >= 1 and <= available bins, per band
    useB  = nSubB >= 2;                         % pass-bands that can carry a slope
    nSub  = sum(nSubB(useB));                   % total # of sub-bands
    if ~warnedSub && ~any(useB)
        warning(['PSI needs >= 2 sub-bands INSIDE one pass-band, but the ' ...
            'widest pass-band of %s holds only %d in-band FFT bin(s) (trial ' ...
            'too short / band too narrow for fs = %g Hz). PSI is set to 0 for ' ...
            'such trials. Use longer epochs or wider bands. (Shown once.)'], ...
            thisFile, max(nBinB), fs);
        warnedSub = true;
    end
    subMask   = zeros(nSub, nT);   % row r = analytic mask of sub-band r
    subBandOf = zeros(nSub, 1);    % row r -> the pass-band it belongs to
    r = 0;
    for bi = 1:nBand
        if ~useB(bi)
            continue;              % this pass-band contributes no sub-band
        end
        edges = linspace(bands(bi,1), bands(bi,2), nSubB(bi) + 1);
        for sbi = 1:nSubB(bi)
            lo = edges(sbi); hi = edges(sbi + 1);
            if sbi < nSubB(bi)
                mB = (freqB >= lo) & (freqB <  hi) & (freqB <= fs/2);
            else
                mB = (freqB >= lo) & (freqB <= hi) & (freqB <= fs/2); % include top edge
            end
            r = r + 1;
            subMask(r, mB)  = 2;
            subBandOf(r)    = bi;
        end
    end
    trScal  = NaN(nMeasure, 7, nTrials);        % (mi, [Cp gamma Lp lambda sigma Eg Eloc], tr)
    trNodal = zeros(nCh, 5, nMeasure, nTrials); % (ch, [Ncp Ne Nle Ndc Nbc], mi, tr); 0 where ch unused
    trOk    = false(nCh, nTrials);              % (ch, tr): channel usable in trial
    ConnAcc = zeros(nCh, nCh, nMeasure);        % sum of connectivity over processed trials
    if keepTrials
        trConn = zeros(nCh, nCh, nMeasure, nTrials);
    else
        trConn = zeros(1, 1, 1, nTrials);       % placeholder (mode not in use)
    end
    parfor (tr = 1:nTrials, nWorkers)
        X = data(:, :, tr);          % nCh x nT (one trial, all channels)
        okCh = all(isfinite(X), 2);  % nCh x 1: channel usable in this trial
        nV   = sum(okCh);            % # nodes in this trial's network
        trOk(:, tr)          = okCh;
        trScal(:, :, tr)     = NaN(nMeasure, 7);
        trNodal(:, :, :, tr) = zeros(nCh, 5, nMeasure);
        if keepTrials
            trConn(:, :, :, tr) = zeros(nCh, nCh, nMeasure);
        else
            trConn(:, :, :, tr) = 0;     % 1 double per trial; never read
        end
        if nV < 3
            continue;                % too few channels for a network (counted after the loop)
        end
        X = X(okCh, :);              % nV x nT (usable channels only)
        scalTr  = NaN(nMeasure, 7);          % row mi = [Cp gamma Lp lambda sigma Eg Eloc]
        nodalTr = zeros(nCh, 5, nMeasure);   % (:,1,mi)=Ncp (:,2,mi)=Ne (:,3,mi)=Nle (:,4,mi)=Ndc (:,5,mi)=Nbc
        connTr  = zeros(nCh, nCh, nMeasure); % (:,:,mi) = connectivity matrix mi
        RandStream.setGlobalStream(RandStream.create('mrg32k3a', ...
            'NumStreams', nTrials, 'StreamIndices', tr, 'Seed', rngSeed));
        Xc = X - mean(X, 2);
        nrm = sqrt(sum(Xc.^2, 2));
        denP = nrm * nrm.';
        Cpear = (Xc * Xc.') ./ denP;
        Cpear(denP == 0) = 0;
        Cpear(1:nV+1:end) = 0;      % zero diagonal
        Xf = fft(X, [], 2);
        Z   = ifft(Xf .* hvec, [], 2);     % nV x nT analytic signal (hvec built above the loop)
        phi = angle(Z);
        Puc = exp(1i * phi);               % unit phase vectors
        S    = (Z * Z') / nT;              % nV x nV complex cross-spectrum
        pw   = real(diag(S));              % per-channel power (>= 0)
        dnS  = sqrt(pw * pw.');
        Cxy  = S ./ dnS;
        Cxy(dnS == 0) = 0;
        MSCmat  = abs(Cxy).^2;             % magnitude-squared coherence
        iCohMat = imag(Cxy);              % imaginary coherency (signed; abs() at thresholding)
        PLVmat = abs(Puc * Puc') / nT;     % (' = conjugate transpose)
        PLImat  = zeros(nV);
        wPLImat = zeros(nV);
        for ii = 1:nV
            CS   = Z(ii,:) .* conj(Z);     % nV x nT, row j = S_ij(t)
            imCS = imag(CS);
            PLImat(ii,:) = abs(mean(sign(imCS), 2)).';
            num = abs(mean(imCS, 2));
            den = mean(abs(imCS), 2);
            wr  = num ./ den;
            wr(den == 0) = 0;
            wPLImat(ii,:) = wr.';
        end
        MSCmat(1:nV+1:end)  = 0;
        iCohMat(1:nV+1:end) = 0;
        PLVmat(1:nV+1:end)  = 0;
        PLImat(1:nV+1:end)  = 0;
        wPLImat(1:nV+1:end) = 0;
        if nSub >= 2
            Csub  = complex(zeros(nV, nV, nSub));
            for sb = 1:nSub
                Zsb   = ifft(Xf .* subMask(sb,:), [], 2);   % nV x nT sub-band analytic sig
                Ssb   = (Zsb * Zsb') / nT;            % sub-band cross-spectrum
                psb   = real(diag(Ssb));
                dnb   = sqrt(psb * psb.');
                Cb    = Ssb ./ dnb;
                Cb(dnb == 0) = 0;
                Csub(:,:,sb) = Cb;
            end
            PSIacc = zeros(nV);
            for sb = 1:(nSub - 1)
                if subBandOf(sb) ~= subBandOf(sb + 1)
                    continue;            % adjacent rows from DIFFERENT pass-bands:
                end                      % no phase slope across the gap
                PSIacc = PSIacc + imag(conj(Csub(:,:,sb)) .* Csub(:,:,sb+1));
            end
            PSImat = PSIacc;             % signed/directed; abs() at thresholding
        else
            PSImat = zeros(nV);         % not enough sub-bands to define a slope
        end
        PSImat(1:nV+1:end) = 0;
        CMcell = {Cpear, MSCmat, iCohMat, PSImat, PLVmat, PLImat, wPLImat};
        for mi = 1:nMeasure
            W = abs(CMcell{mi});
            W(1:nV+1:end) = 0;
            W = (W + W.') / 2;                  % remove round-off asymmetry
            A = double(threshold_proportional(W, sparsity) ~= 0);
            A3  = A * A * A;
            triN = diag(A3) / 2;                % triangles per node
            NleV = triN;                        % "number of local edges"
            NcpV  = clustering_coef_bu(A);      % nV x 1
            CpVal = mean(NcpV);
            NdcV = degrees_und(A).';            % nV x 1
            D = A; D(A == 0) = Inf; D(1:nV+1:end) = 0;
            for kk = 1:nV
                D = min(D, D(:, kk) + D(kk, :));
            end
            Dinv = 1 ./ D;
            Dinv(~isfinite(Dinv)) = 0;
            Dinv(1:nV+1:end) = 0;
            NeV   = sum(Dinv, 2) / (nV - 1);            % nodal efficiency
            EgVal = efficiency_bin(A);                  % global efficiency
            LpVal = charpath(D, 0, 0);                  % char. path length
            NbcV = betweenness_bin(A).' / 2;    % nV x 1; /2 = each unordered pair once
            ElocV   = efficiency_bin(A, 1);     % nV x 1
            ElocVal = mean(ElocV);
            CpRand = zeros(nSurrogate, 1);
            LpRand = zeros(nSurrogate, 1);
            for sgi = 1:nSurrogate
                Ar = A;
                [ri, rj] = find(triu(Ar, 1));
                nE = numel(ri);
                if nE >= 2
                    for att = 1:(swapFactor * nE)
                        e1 = randi(nE); e2 = randi(nE);
                        if e1 == e2, continue; end
                        a = ri(e1); b = rj(e1);
                        cc = ri(e2); dd = rj(e2);
                        if numel(unique([a b cc dd])) < 4, continue; end
                        if Ar(a,dd) || Ar(cc,b), continue; end  % no double edge
                        Ar(a,b)=0; Ar(b,a)=0; Ar(cc,dd)=0; Ar(dd,cc)=0;
                        Ar(a,dd)=1; Ar(dd,a)=1; Ar(cc,b)=1; Ar(b,cc)=1;
                        rj(e1) = dd; rj(e2) = b;
                    end
                end
                CpRand(sgi) = mean(clustering_coef_bu(Ar));
                Dr = Ar; Dr(Ar == 0) = Inf; Dr(1:nV+1:end) = 0;
                for kk = 1:nV
                    Dr = min(Dr, Dr(:, kk) + Dr(kk, :));
                end
                LpRand(sgi) = charpath(Dr, 0, 0);
            end
            mCpR = mean(CpRand(isfinite(CpRand)));
            mLpR = mean(LpRand(isfinite(LpRand)));
            if isfinite(mCpR) && mCpR > 0, gammaVal = CpVal / mCpR; else, gammaVal = NaN; end
            if isfinite(mLpR) && mLpR > 0, lambdaVal = LpVal / mLpR; else, lambdaVal = NaN; end
            sigmaVal = gammaVal / lambdaVal;
            scalTr(mi, :) = [CpVal gammaVal LpVal lambdaVal sigmaVal EgVal ElocVal];
            nodalTr(okCh, 1, mi)   = NcpV;
            nodalTr(okCh, 2, mi)   = NeV;
            nodalTr(okCh, 3, mi)   = NleV;
            nodalTr(okCh, 4, mi)   = NdcV;
            nodalTr(okCh, 5, mi)   = NbcV;
            connTr(okCh, okCh, mi) = CMcell{mi};
        end % measures
        trScal(:, :, tr)     = scalTr;         % sliced output
        trNodal(:, :, :, tr) = nodalTr;        % sliced output
        if keepTrials
            trConn(:, :, :, tr) = connTr;      % sliced output (trial-kept only)
        end
        ConnAcc = ConnAcc + connTr;            % parfor reduction (sum over trials)
    end % trials
    nValidChPerTrial = sum(trOk, 1);           % 1 x nTrials: usable channels per trial
    usedTr = nValidChPerTrial >= 3;            % trials that were processed
    nOK    = sum(usedTr);
    nSkipTrial = nTrials - nOK;
    if nSkipTrial > 0
        fprintf('    %d of %d trial(s) skipped (< 3 usable channels).\n', ...
                nSkipTrial, nTrials);
    end
    if nOK == 0
        warning('File %s: no trial has >= 3 usable channels -- skipped.', thisFile);
        fileStatus{k} = 'skipped: no trial with >= 3 usable channels';
        continue;
    end
    okUsed = double(trOk(:, usedTr));          % nCh x nOK
    nChT   = sum(okUsed, 2);                   % nCh x 1
    nPairT = okUsed * okUsed.';                % nCh x nCh
    if keepTrials
        okUse = trOk;
        okUse(:, ~usedTr) = false;                                   % nCh x nTrials
        pairOK = reshape(okUse, nCh, 1, nTrials) & reshape(okUse, 1, nCh, nTrials);
    end
    results = struct();
    for mi = 1:nMeasure
        mn = measureNames{mi};
        if keepTrials
            sc = reshape(trScal(mi, :, :), 7, nTrials);   % rows = Cp gamma Lp lambda sigma Eg Eloc
            results.(mn).Cp     = sc(1, :);               % 1 x nTrials
            results.(mn).gamma  = sc(2, :);               % 1 x nTrials (NaN where undefined)
            results.(mn).Lp     = sc(3, :);
            results.(mn).lambda = sc(4, :);
            results.(mn).sigma  = sc(5, :);
            results.(mn).Eg     = sc(6, :);
            results.(mn).Eloc   = sc(7, :);
            Ncp = reshape(trNodal(:, 1, mi, :), nCh, nTrials); Ncp(~okUse) = NaN;
            Ne  = reshape(trNodal(:, 2, mi, :), nCh, nTrials); Ne(~okUse)  = NaN;
            Nle = reshape(trNodal(:, 3, mi, :), nCh, nTrials); Nle(~okUse) = NaN;
            Ndc = reshape(trNodal(:, 4, mi, :), nCh, nTrials); Ndc(~okUse) = NaN;
            Nbc = reshape(trNodal(:, 5, mi, :), nCh, nTrials); Nbc(~okUse) = NaN;
            results.(mn).Ncp = Ncp;                       % nCh x nTrials
            results.(mn).Ne  = Ne;                        % nCh x nTrials
            results.(mn).Nle = Nle;                       % nCh x nTrials
            results.(mn).Ndc = Ndc;                       % nCh x nTrials (degree)
            results.(mn).Nbc = Nbc;                       % nCh x nTrials (betweenness)
            CM = reshape(trConn(:, :, mi, :), nCh, nCh, nTrials);
            CM(~pairOK) = NaN;
            results.(mn).ConnMatrix = CM;
            continue;                % measure done; nothing is averaged here
        end
        sc = reshape(trScal(mi, :, usedTr), 7, nOK);  % rows = Cp gamma Lp lambda sigma Eg Eloc
        results.(mn).Cp     = sum(sc(1, :)) / nOK;
        results.(mn).Lp     = sum(sc(3, :)) / nOK;
        results.(mn).Eg     = sum(sc(6, :)) / nOK;
        results.(mn).Eloc   = sum(sc(7, :)) / nOK;
        results.(mn).Ncp    = sum(trNodal(:, 1, mi, usedTr), 4) ./ nChT;  % nCh x 1 (NaN = never usable)
        results.(mn).Ne     = sum(trNodal(:, 2, mi, usedTr), 4) ./ nChT;  % nCh x 1
        results.(mn).Nle    = sum(trNodal(:, 3, mi, usedTr), 4) ./ nChT;  % nCh x 1
        results.(mn).Ndc    = sum(trNodal(:, 4, mi, usedTr), 4) ./ nChT;  % nCh x 1 (degree)
        results.(mn).Nbc    = sum(trNodal(:, 5, mi, usedTr), 4) ./ nChT;  % nCh x 1 (betweenness)
        gv = sc(2, :); gv = gv(isfinite(gv)); if ~isempty(gv), results.(mn).gamma  = sum(gv) / numel(gv); else, results.(mn).gamma  = NaN; end
        lv = sc(4, :); lv = lv(isfinite(lv)); if ~isempty(lv), results.(mn).lambda = sum(lv) / numel(lv); else, results.(mn).lambda = NaN; end
        sv = sc(5, :); sv = sv(isfinite(sv)); if ~isempty(sv), results.(mn).sigma  = sum(sv) / numel(sv); else, results.(mn).sigma  = NaN; end
        CC = ConnAcc(:, :, mi) ./ nPairT;
        dgIdx = 1:nCh+1:nCh*nCh;
        CC(dgIdx(nChT > 0)) = 0;
        results.(mn).ConnMatrix = CC;                    % nCh x nCh
    end
    results.nChannels        = nCh;                      % incl. dead channels
    results.nTrials          = nTrials;                  % trials in file
    results.nTrialsUsed      = nOK;                      % trials processed
    results.deadChannels     = find(chanDead);           % all-NaN channel indices
    results.nTrialsPerChannel = nChT;                    % nCh x 1 (0 = dead)
    results.nValidChPerTrial = nValidChPerTrial;         % 1 x nTrials (< 3 = skipped)
    results.trialMode        = trialMode;                % 'averaged' or 'trial-kept'
    allResults{k} = results;
    fileStatus{k} = 'done';
    if saveResults
        outFile = fullfile(outFolders{k}, outMatFile);
        meta.dataFile  = thisFile;
        meta.relFolder = relFolders{k};
        meta.created   = datestr(now);
        try
            save(outFile, 'results', 'meta', 'decodeScore', 'runID', '-v7.3');
            fprintf('  saved -> %s\n', outFile);
        catch ME
            warning('Could not save %s (%s).', outFile, ME.message);
            fileStatus{k} = 'done (NOT saved)';
        end
    end
end % data files
runSummary = table(relFolders, dataFiles, fileStatus, ...
                   'VariableNames', {'Folder', 'DataFile', 'Status'});
nDone = sum(strncmp(fileStatus, 'done', 4));
fprintf('\nDone. %d of %d data file(s) processed, %d skipped (see runSummary).\n', ...
        nDone, nFiles, nFiles - nDone);
fprintf('\nHOW TO ACCESS RESULTS\n');
if saveResults && ~isempty(saveAbs)
    fprintf('  The folder tree of rootDir is mirrored under\n    %s\n', saveAbs);
    fprintf('  and each of its folders holds one %s with four variables:\n', outMatFile);
elseif saveResults
    fprintf('  Each data folder now holds %s with four variables:\n', outMatFile);
else
    fprintf('  saveResults = false, so nothing was written; the structs below\n');
    fprintf('  live in allResults only. Each of them holds:\n');
end
fprintf('    results : struct, results.<Measure>.<Metric>\n');
fprintf('    meta    : parameters used + the data file the results belong to\n');
if saveResults
    fprintf('    decodeScore : copied unchanged from the data file ([] if it had none)\n');
    fprintf('    runID       : copied unchanged from the data file ([] if it had none)\n');
end
fprintf('  Measures : %s\n', strjoin(measureNames, ', '));
if keepTrials
    fprintf('  Trial mode : trial-kept -- every field has a trailing TRIAL dimension\n');
    fprintf('    Scalars  : %s  (1 x nTrials each)\n', strjoin(metricScalars, ', '));
    fprintf('    Vectors  : %s  (nCh x nTrials each)\n', strjoin(metricVectors, ', '));
    fprintf('    ConnMatrix : nCh x nCh x nTrials\n');
    fprintf('    Column tr is trial tr of the data file, so it lines up with\n');
    fprintf('    decodeScore(tr) and runID(tr). NaN = trial not processed\n');
    fprintf('    (< 3 usable channels) or channel not usable in that trial.\n');
else
    fprintf('  Trial mode : averaged -- metrics averaged over the processed trials\n');
    fprintf('  Scalars  : %s\n', strjoin(metricScalars, ', '));
    fprintf('  Vectors  : %s  (one value per channel)\n', strjoin(metricVectors, ', '));
end
fprintf('  Examples :\n');
fprintf('    S = load(fullfile(resultFolder, ''%s''));   %% resultFolder = outFolders{k}\n', outMatFile);
fprintf('    S.results.PLV.Cp        %% clustering coefficient, PLV network\n');
fprintf('    S.results.wPLI.Eg       %% global efficiency, wPLI network\n');
fprintf('    S.results.MSC.Ncp       %% nodal clustering vector, MSC network\n');
fprintf('    S.results.PLI.Nbc       %% nodal betweenness vector, PLI network\n');
if keepTrials
    fprintf('    S.results.PLV.Cp(tr)        %% clustering coefficient of trial tr\n');
    fprintf('    S.results.MSC.Ncp(ch, tr)   %% nodal clustering of channel ch, trial tr\n');
    fprintf('    S.results.iCoh.ConnMatrix(:, :, tr)  %% that trial''s iCoh matrix\n');
    fprintf('    corr(S.results.PLV.Eg(:), S.decodeScore(:), ''rows'', ''complete'')\n');
    fprintf('                                %% single-trial metric vs decodeScore\n');
end
if saveResults
    fprintf('    S.decodeScore, S.runID  %% trial vectors from the data file\n');
    fprintf('    S.decodeScore(S.results.nValidChPerTrial >= 3)   %% scores of the processed trials\n');
end
fprintf('  In this workspace, allResults{k} is the same struct for data file k\n');
fprintf('  (folder relFolders{k}, path dataFiles{k}; [] if skipped -- see runSummary),\n');
fprintf('  and outFolders{k} is the result folder that goes with it.\n');
fprintf('  NaN entries in the nodal vectors or NaN rows/cols in ConnMatrix mark channels that\n');
fprintf('  were all-NaN in the data (positions kept; see results.deadChannels).\n');
fprintf('\nTIP: to pull one scalar metric across all data files into a vector for\n');
fprintf('     stats, loop the cells, e.g.:\n');
fprintf('       M = nan(%d,1);\n', nFiles);
fprintf('       for kk = 1:%d\n', nFiles);
fprintf('         s = allResults{kk};\n');
fprintf('         if ~isempty(s), M(kk) = s.PLV.Eg; end\n');
fprintf('       end\n');