%% Batch 1
% EEG files should be ".cnt" format. In this code, we name the files
% from 1 to 40.
data_path = '';% The directory of EEG data waiting preprocessing
save_path = '';% Your saving path
cd(data_path);
for i = 1:40
    setname = [num2str(i),'.set'];% The saved data should be ".set" format. You can change the name according to your preference
    importname = [data_path,num2str(i),'_convert.cdt.cnt'];
    EEG = pop_loadcnt(importname , 'dataformat', 'auto', 'memmapfile', '');
    EEG = eeg_checkset( EEG );
    EEG=pop_chanedit(EEG, 'lookup','F:\\Toolbox\\eeglab2021.0\\plugins\\dipfit\\standard_BEM\\elec\\standard_1005.elc');% Change to the directory where the "standard_1005.elc" exists
    EEG = pop_select( EEG, 'channel',{'Fp1','Fpz','Fp2','AF3','AF4','F7','F5','F3','F1','Fz','F2','F4','F6','F8','FC5','FC3','FC1','FCz','FC2','FC4','FC6','T7','C5','C3','C1','Cz','C2','C4','C6','T8','TP7','CP5','CP3','CP1','CPz','CP2','CP4','CP6','TP8','M1','M2','P7','P5','P3','P1','Pz','P2','P4','P6','P8','PO7','PO3','POz','PO4','PO8','O1','Oz','O2'});
    EEG = pop_eegfiltnew(EEG, 'locutoff',0.5,'plotfreqz',0);
    EEG = pop_eegfiltnew(EEG, 'hicutoff',80,'plotfreqz',0);
    EEG = pop_eegfiltnew(EEG, 'locutoff',48,'hicutoff',52,'revfilt',1,'plotfreqz',0);
    EEG = pop_epoch( EEG, {}, [-1  2], 'newname', 'CNT file resampled epochs', 'epochinfo', 'yes');% The mark should be filled in the "{}"
    EEG = pop_rmbase( EEG, [-1000  0],[]);

    % Delete trials with incorrect response
    correctness_list = pre(:,i);% You should creat a "pre" matrix in shape of trials * subjects to store the correctness of each trial. 1 and 0 represent correct and false, respectively.
    wrong_trials = find(correctness_list == 0);
    if ~isempty(wrong_trials)
        EEG = pop_select(EEG, 'notrial', wrong_trials);
    end

    EEG = pop_saveset(EEG, 'filename', setname, 'filepath', save_path);
    clear correctness_list wrong_trials;
end

%% Discarding bad trials and interpolating bad channels
% Discarding bad trials
set_name = '';% Your set name
save_neme = set_name;
set_path = '';% The directory of EEG data waiting further preprocessing
save_path = '';% Your saving path
EEG = pop_loadset('filename', set_name, 'filepath', set_path);
pop_eegplot( EEG, 1, 1, 1);

% Interpolating bad channels
EEG = pop_interp(EEG, [22], 'spherical');

% Save your data
EEG = pop_saveset(EEG, 'filename', save_neme, 'filepath', save_path);

%% Batch 3
data_path = '';% The directory of EEG data waiting further preprocessing
save_path = '';% Your saving path
Subj = [1:40];
for i = Subj
    setname = [num2str(i),'.set'];
    EEG = pop_loadset('filename', setname, 'filepath', data_path);
    EEG = pop_reref( EEG, [] );% Fill in your rereference channels
    EEG = pop_runica(EEG, 'icatype', 'runica', 'extended',1,'interrupt','on');
    EEG = pop_saveset(EEG, 'filename', setname, 'filepath', save_path);
end

%% Batch 4
set_pamnth = '';% The directory of EEG data waiting further preprocessing
save_path = '';% Your saving path
Subj = 1:40;
for i=Subj
    set_name = strcat(num2str(i),'.set');
    EEG = pop_loadset('filename',set_name,'filepath',set_path);
    EEG = pop_iclabel(EEG, 'default');
    EEG = pop_icflag(EEG, [NaN NaN;0.9 1;0.9 1;0.9 1;0.9 1;0.9 1;NaN NaN]); % Brain, Muscle, Eye, Heart, Line Noise, Channel Noise, Other.
    EEG = pop_subcomp( EEG, [], 0);
    EEG = eeg_checkset( EEG );
    EEG = pop_saveset( EEG, 'filename',set_name, 'filepath',save_path);
end