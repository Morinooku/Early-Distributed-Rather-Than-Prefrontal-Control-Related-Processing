%% Basic configuration file for MVPA analysis - Folder and data files:

% cfg.analysis = 'MVCC';
% cfg.location = pwd;
% 
% cfg.study.conditionIdentifier{1,1} = 'condition_1';
% cfg.study.conditionIdentifier{1,2} = 'condition_2';
% cfg.study.conditionIdentifier{2,1} = 'condition_3';
% cfg.study.conditionIdentifier{2,2} = 'condition_4';
% 
% cfg.study.dataPaths{1,1} = '/Users/David/Desktop/data/condition_1/';
% cfg.study.dataPaths{1,2} = '/Users/David/Desktop/data/condition_2/';
% cfg.study.dataPaths{2,1} = '/Users/David/Desktop/data/condition_3/';
% cfg.study.dataPaths{2,2} = '/Users/David/Desktop/data/condition_4/';
% 
% cfg.study.dataFiles{1,1} = {'1.mat','2.mat','3.mat'};
% cfg.study.dataFiles{1,2} = {'1.mat','2.mat','3.mat'};
% cfg.study.dataFiles{2,1} = {'1.mat','2.mat','3.mat'};
% cfg.study.dataFiles{2,2} = {'1.mat','2.mat','3.mat'};

cfg.analysis = 'MVPA';
cfg.location = '';%where results store

cfg.study.conditionIdentifier{1,1} = 'condition_1';
cfg.study.conditionIdentifier{1,2} = 'condition_2';

cfg.study.dataPaths{1,1} = '';
cfg.study.dataPaths{1,2} = '';

cfg.study.dataFiles{1,1} = {''};
cfg.study.dataFiles{1,2} = {''};




%% FEATURE EXTRACTION:

cfg.feature = 'voltage';

% cfg.feature = 'voltage'  - Raw voltage as feature.
% cfg.feature = 'envelope' - Power evelope as feature.

cfg.powenv.method = 'analytic';
cfg.powenv.uplow  = 'upper';
cfg.powenv.length = 5;

% cfg.powenv.method = 'analytic' - Envelope using the analytic signal.
% cfg.powenv.method = 'peak'     - Peak envelopes.

% cfg.powenv.uplow = 'upper' - Select upper envelope.
% cfg.powenv.uplow = 'lower' - Select lower envelope.

%% TRIAL AVERAGE:

% cfg.trialaver.flag     = true;
% cfg.trialaver.ntrials  = 5;
% cfg.trialaver.order    = 'rand';

% cfg.trialaver.order = 'rand' - Random order.
% cfg.trialaver.order = 'seq'  - Secuential order.

%% BALANCED DATASETS:

cfg.classsize.match = true;
cfg.classsize.matchkfold = true;

%% DIMENSION REDUCTION:

% cfg.dimred.method = 'none' - Diemnsion reduction disabled.
% cfg.dimred.method = 'pca'  - Principal Component Analysis.

cfg.dimred.method = 'none';
cfg.dimred.ncomp  = 0;

%% DATA NORMALIZATION:

% cfg.normdata = 0 - raw data
% cfg.normdata = 1 - z-score (across features)
% cfg.normdata = 2 - z-score (across time)
% cfg.normdata = 3 - z-score (across trials)
% cfg.normdata = 4 - std_nor (across trials)

cfg.normdata = 1; 

%% DATA SMOOTHING:

% cfg.smoothdata.method = 'none'     - Data smooth disabled.
% cfg.smoothdata.method = 'moving'   - Moving average method.
% cfg.smoothdata.method = 'gaussian' - Gaussian kernel.

cfg.smoothdata.method   = 'moving';
cfg.smoothdata.window   = 5;

%% ANALYSIS TIMING:

cfg.tm.tpstart   = -300;
cfg.tm.tpend     = 1500;%%%%%%%%%%%%%%%%%%
cfg.tm.tpstart_  = -300;
cfg.tm.tpend_    = 1500;%%%%%%%%%%%%%%%%%%
cfg.tm.tpsteps   = 1;

%% CLASSIFICATION ALGORITHM:

% cfg.classmodel.method = 'svm' - Support Vector Machine.
% cfg.classmodel.method = 'da'  - Linear Discriminant Analysis.

% cfg.classmodel.kernel = 'linear'     - Support Vector Machine.
% cfg.classmodel.kernel = 'gaussian'   - Support Vector Machine.
% cfg.classmodel.kernel = 'rbf'        - Support Vector Machine.
% cfg.classmodel.kernel = 'polynomial' - Support Vector Machine.

% cfg.classmodel.kernel = 'linear' - Discriminant Analysis.
% cfg.classmodel.kernel = 'quadratic' - Discriminant Analysis.

cfg.classmodel.method = 'da';
cfg.classmodel.kernel = 'linear';

%% PERFORMANCE METRICS:

cfg.classmodel.roc       = true;
cfg.classmodel.auc       = true;
cfg.classmodel.confmat   = true;
cfg.classmodel.precision = true;
cfg.classmodel.recall    = true;
cfg.classmodel.f1score   = true;
cfg.classmodel.wvector   = false;

%% EXTRA CONFIGURATION:

%cfg.classmodel.tempgen = true;
cfg.classmodel.tempgen = false;
cfg.classmodel.extdiag = false;
cfg.classmodel.permlab = false;

% Enable parallel computation by default if the Distrib_Computing_Toolbox 
% is installed: 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% if license('test','Distrib_Computing_Toolbox')
%     cfg.classmodel.parcomp = true;
% else
%     cfg.classmodel.parcomp = false;
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
try
    pool = gcp('nocreate');
    if isempty(pool)
        fprintf('Starting parallel pool...\n');
        
        % Specify number of workers based on your system
        % Option 1: Use all physical cores
        %numWorkers = feature('numcores');  % Gets physical cores (96 in your case)
        
        % Option 2: Use a specific number (recommended to leave some cores free)
        numWorkers = 24;  % Leave 6 cores for system/other tasks
        
        pool = parpool('local', numWorkers);
    end
    pool.IdleTimeout = 360;
    fprintf('Parallel pool ready: %d workers, IdleTimeout: %d min\n\n', ...
        pool.NumWorkers, pool.IdleTimeout);
catch ME
    warning('Parallel pool not available: %s\nRunning in serial mode.', ME.message);
    if exist('config', 'var')
        config.useParallel = false;
    end
end
%% CROSS-VALIDATIONN PROCEDURE:

% cfg.cv.method = 'kfold' - K-Fold cross-validation.
% cfg.cv.method = 'loo'   - Leave-one-out cross-validation.

cfg.cv.method  = 'kfold';
cfg.cv.nfolds  = 5;

%% PERMUTATION TEST

cfg.stats.flag   = 1;
cfg.stats.nper   = 1000;% per sub
cfg.stats.nperg  = 1e+5;% per group
cfg.stats.pgroup = 95;
cfg.stats.pclust = 95;
cfg.stats.tails  = 2;
cfg.stats.shownulldis = 0;
